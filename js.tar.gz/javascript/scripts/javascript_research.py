import requests
import re
import os
import hashlib

def get_js():
    domains = ['pl16123190.gatetotrustednetwork.com/6e/7f/d9/6e7fd993ff6b08a698ba3d2a8cd67a61.js', 'pl15939612.revenuenetworkcpm.com/12/10/a5/1210a50201cdce946f865b27a08f8f85.js', 'pl16065720.profitabletrustednetwork.com/29/a6/22/29a622f3708706f2519a14d65918647d.js', 'hiddenlocationpredicate.com/ee/27/f7/ee27f7d71a8dc31349d5d6f45816390f.js', 'cartrigestale.com/a2/f5/d2/a2f5d279d24ece255dabdf18f5692f61.js', 'tiltgardenheadlight.com/16/0b/fa/160bfaa498ea0916b74a00871b43bc73.js', 'ghostsinstance.com/9c/e6/00/9ce60043e3808528018c7fb364f6b852.js', 'cartrigestale.com/04/e4/50/04e45006ecae2b0aeb462ac5de7f0a4a.js', 'ghostsinstance.com/e0/7d/dd/e07ddd58316e26cd810877fa9b0ebe12.js', 'colouredcavity.com/62/f4/25/62f425b13c2294da628205a39237b933.js', 'cartrigestale.com/49/b6/e9/49b6e9a5c41d7852560556659980257f.js', 'emailwhilefactory.com/29/a6/22/29a622f3708706f2519a14d65918647d.js', 'cartrigestale.com/eb/dc/e8/ebdce8b12037d72e302939f3afccfc73.js', 'pl16220625.highperformancecpmnetwork.com/11/b2/82/11b282e15e245d91db0836a99a44c977.js', 'learningaware.com/46/39/e8/4639e8657dcb96eef3abcc80ab4867aa.js', 'choplivelychat.com/dd/3e/c6/dd3ec60081d9b557f009e8c02e4fa02c.js', 'cartrigestale.com/7b/48/82/7b48823ed93b874fb7cf60233206b266.js', 'pl15974843.topprofitablecpm.com/94/38/79/9438798de8bf9abad54c44606833c3f5.js', 'unrulyrotate.com/6f/e5/9f/6fe59f4e3623818e872d85621f730c0c.js', 'ethicel.com/08/a9/8a/08a98ab2f50a0f1c2b65c0d6746b32d5.js', 'artreconnect.com/66/65/61/6665613866346561623438343131383631653761316166343761383038653064.js', 'basheighthnumerous.com/5d/e3/27/5de327c18e9977353aef950cca828070.js', 'successfulascertained.com/e0/5c/bc/e05cbc04c7455b442d2d0393ea6c23a4.js', 'pl15894284.revenuenetworkcpm.com/c4/e6/83/c4e683ddfd647d65f68b4b472b70f738.js', 'somehowluxuriousreader.com/51/f0/5d/51f05d69f8d2fa082e93c80273ec8a1e.js', 'contributorshaveangry.com/ad/2d/d7/ad2dd7677886e7a55b825d17bf802a02.js', 'faintestlogic.com/ee/bd/43/eebd4379fff627e532f133db6c965414.js', 'pl16123193.gatetotrustednetwork.com/31/9b/7a/319b7a594efd1451516cfbccb86e67cd.js', 'b81oidrmy82w.com/29/b5/52/29b552ac181cd0b221e0fcc9e06f6754.js', 'familyborn.com/6b/1e/aa/6b1eaaee6046bcfa9e10a7b82dd6c17e.js', 'waggonerchildrensurly.com/74/12/ef/7412ef6c5e8d8ef48526de7e6672209e.js', 'pl15993135.revenuenetworkcpm.com/70/be/e0/70bee0bb977f009e7c56977023501e43.js', 'lashquivercakes.com/3c/54/2e/3c542ed52af8d3b9d786b958381a012f.js', 'pl16061454.profitabletrustednetwork.com/f2/ce/79/f2ce7927eccfb176fb281fa0a0cac2f5.js', 'pl16055399.highrevenuecpm.com/76/87/ad/7687ad14a5c1d4b9e129061ad1b2e863.js', 'skillpropulsion.com/c3/ae/45/c3ae454249e968fc0a9cef4cf1d49e7e.js', 'misguidedstork.com/6e/40/1c/6e401cc1b2ec92483edc9129b4cf8061.js', 'cartrigestale.com/37/11/05/37110569bb3a3e74f28a744466fc38b4.js', 'waggonerchildrensurly.com/45/81/31/458131915c294bcf8e75531092f1b040.js', 'cartrigestale.com/2e/65/64/2e6564a396ae58dbf6dc0554beb199b0.js', 'pl16025977.revenuenetworkcpm.com/59/a2/be/59a2bef8a367074a165b41d79eae1317.js', '1.download.advertise.myspace.com/03/2f/3b/ed2f3bb45e08507543a0b9d56a6f642e_behave.js', 'pl16167675.highperformancecpmnetwork.com/ad/ea/37/adea37339f9a045680938c3556e6cab8.js', 'loyalinvadeballoon.com/65/aa/28/65aa283021630dfd9030555c4c61a78c.js', 'cartrigestale.com/bc/f6/23/bcf623a3cb5e0061259980d8557c0566.js', 'cartrigestale.com/5f/cd/f8/5fcdf85389b90d21eed96eec9719f352.js', 'pl16110581.revenuecpmnetwork.com/93/dc/ef/93dcef13ea1494d443c32d276381fca4.js', 'contributorshaveangry.com/0e/df/bd/0edfbd4491cc864c6e43345318d9c70f.js', 'legcatastrophetransmitted.com/af/87/d2/af87d26cb78c409e095bcd4824fbeff4.js', 'pl16065720.highrevenuecpm.com/29/a6/22/29a622f3708706f2519a14d65918647d.js', 'wowcalmnessdumb.com/a2/50/55/a2505511ed28efb7ae80ec9f0d4854a5.js', 'pl15871443.revenuenetworkcpm.com/82/54/29/825429a07acc8a5e481c37cbefedb7ae.js', 'enginedriverflexible.com/e3/9e/6d/e39e6de78434e75a812da1a674f8e022.js', 'affableindigestionstruggling.com/93/27/d1/9327d17a0f16a08ec79502b78ffdb077.js', 'faintestlogic.com/60/75/39/607539f488bd670e404e54b93f31ae59.js', 'ablebodiedcool.com/53/3e/55/533e55fb15e3044dc13b6aba6c3f5c55.js', 'cyberaircraftcast.com/53/b2/47/53b247c592b30a42e71aae197ca6e637.js', 'saggrowledetc.com/11/75/d4/1175d4358c6880ccd479e86b90e1f6ff.js', 'causerestrainrecorder.com/cd/62/be/cd62bec6ed326a84f61fbf3e4db7ff27.js']
    user_agent = {'User-agent': 'Mozilla/5.0'}

    for d in domains:
        req = requests.get('https://' + d, verify=False, headers=user_agent)
        with open(d.split('/')[-1], 'w') as d:
            d.write(req.text)

def hash_js():
    hashes = dict()
    files = [i for i in os.listdir() if re.match('.*js$',i)]
    for file in files:
        with open(file) as f:
            buf = f.read().encode('utf-8')
            m = hashlib.sha256()
            m.update(buf)
            # filehash = hasher.update(buf)
            hashes[file] = m.hexdigest()
    return hashes


print(hash_js())