var _0xb050 = ['-99999px', 'readyState', 'checkBlock', 'detect', 'map', 'pages', 'pages', '40', '0', '6', '0', 'http://braggingreorganizeunderworld.com/yb841hx3e', '&scrHeight=', '&tz=', 'getTimezoneOffset', '&ship=', '&pst=', '&dev=', 'isEmulate', 'false', 'false', 'https://cdn.cloudimagesb.com/36/template/pu1473410272.pdf', '', '', 'false', 'true', 'false', '100', 'getArr', 'exclude', '20.8.v.1', '[object\x20Array]', 'length', 'ppu_exp_', 'ppu_clicks_', 'key', 'ppu_show_on_', 'ppu_sub_', 'ppu_delay_', 'ppu_idelay_', 'No\x20available\x20storage', 'ppu_show_on', 'getTime', 'setStorage', ';\x20expires=', 'cookie', '\x20expires=', '\x20path=/', 'localStorage', 'expires', 'parse', 'isLocalStorageAvailable', 'setItem', 'addBehavior', '#default#userData', 'setAttribute', 'save', 'auth', 'getItem', 'load', 'removeItem', 'removeAttribute', 'storageSupport', 'code', 'QUOTA_EXCEEDED_ERR', 'trim', 'getQuery', 'concat', 'pvarr', 'pearr', 'isDescendant', 'dtnoppu', 'include', 'findUpTag', 'javascript:', 'appendFingerprint', 'defineProperty', 'winphone', 'addMobileEventListener', 'mousemove', 'mousedown', 'touchend', 'new_webview', 'firefox', 'html', 'clientX', 'attachEvent', 'onclick', 'msie', 'srcElement', 'hardcore', 'onbeforeunload', 'ppu_idelay', 'init_delay', 'overlayName', 'getElementsByClassName', '100%', 'fixed', '3000', 'backgroundImage', 'url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)', 'createTransparentLayer', 'false', '', 'false', '', 'stack', 'message', 'freeze', 'true', '//braggingreorganizeunderworld.com/pixel/', '474', '15d6ce62d0f01528c7478f7446d71678', 'placementKey', 'slice', 'script', 'initiatorType', 'test', 'filter', 'domainLookupStart', 'connectEnd', 'connectStart', 'secureConnectionStart', 'responseEnd', 'responseStart', 'requestStart', 'startTime', 'buildVersion', 'templateId', 'keys', 'join', 'src', 'baseURL', 'performance', 'getEntriesByType', 'findPopsScriptEntry', 'resource', 'purst', 'serializeQueryData', 'touchPixel', 'purs?tmpl=', '&bv=', 'isMetricsEnabled', 'puclc?tmpl=', '&plk=', 'open', 'Content-Type', 'application/json', 'send', 'stringify', 'sendNetworkMetrics', 'getElementsByTagName', 'head', 'title', 'textContent', 'innerText', 'floor', 'random', 'abcdefghijklmnopqrstuvwxyz', 'split', 'top', 'location', 'href', '&kw=', 'userAgent', 'toLowerCase', 'match', 'version', 'safari', 'iosVer', 'ios', 'chrome', 'mac', 'string', 'document', 'toString', '_parent', 'window', 'innerHeight', 'clientHeight', 'body', 'number', 'innerWidth', 'documentElement', 'clientWidth', 'screenTop', 'screenY', 'screenLeft', 'screen', 'template', 'timing', 'period', 'getCookie', 'ppu_total_count', 'max_per_page', 'ppu_sub', 'shown', 'max', 'ppu_delay', 'isArray', 'show_on', 'indexOf', 'showOnCounter', 'clicks', 'ppu_clicks', 'swipeEvent', 'inXP', 'target', 'tagName', 'ftg', 'brs', 'clickedUrl', 'isLink', 'android', 'popunder', 'stopEventPropagation', 'init', 'addEventListener', 'setCookieCount', 'preventDefault', 'returnValue', 'popunderCondition', 'click', 'preventIosClick', 'swipe', 'ios9', 'touchstart', 'touchmove', 'removeEventListener', 'clickCounter', 'ppu_exp', 'opener', 'stopPropagation', 'cancelBubble', 'getElementById', 'createElement', 'div', 'transpLayerId', 'style', 'bottom', 'left', 'right', 'zIndex', '2147483650', 'background', 'black', 'opacity', '.01', 'GetWindowHeight', 'width', 'GetWindowWidth', 'url', '_blank', 'display', 'block', 'height', 'inherit', 'AaDetector', 'aParam', 'appendChild', 'write', '<body>', '</body>', 'origin', '\x27;\x20},\x20', 'aa_redirect_delay', 'DOMContentLoaded', 'parentNode', 'removeChild', 'ppu_main', 'setCookie', 'delay', 'windowOpenerNull', 'removeTransparentLayer', 'sendClickMetrics', 'aa_redirect', 'isA', 'openLinkWithRedirect', 'text/javascript', '//braggingreorganizeunderworld.com/', 'substr', '.js', 'forEach', 'result', 'hasOwnProperty', 'opera', 'some', 'MSInputMethodContext', 'documentMode', '[object\x20OperaMini]', 'prototype', 'call', 'LieDetector', 'type', 'text/css', 'fake', 'styleSheet', 'cssText', 'createTextNode', 'overflow', 'hidden', 'offsetHeight', 'function', 'falsePoints', 'push', 'addTest', 'hasFileInputMultiple', 'multiple', 'hasCustomProtocolHandler', 'registerProtocolHandler', 'hasCrypto', 'crypto', 'hasNotification', 'Notification', 'requestPermission', 'permission', 'TypeError', 'name', 'hasSharedWorkers', 'SharedWorker', 'capture', 'input', 'hasTouchEvents', 'ontouchstart', 'DocumentTouch', '@media\x20(touch-enabled),(-webkit-touch-enabled),(-moz-touch-enabled),', '(-o-touch-enabled),(-ms-touch-enabled){#liedetector{top:7px;position:absolute}}', 'offsetTop', 'orientation', 'hasDevToolsOpen', 'console', 'firebug', 'undefined', '__defineGetter__', 'log', 'clear', 'availWidth', 'availHeight', 'hasLiedOs', 'oscpu', 'platform', 'Windows\x20Phone', 'xbox', 'Xbox', 'win', 'Windows', 'Android', 'cros', 'Chrome\x20OS', 'linux', 'Linux', 'iphone', 'ipad', 'iOS', 'Mac', 'Other', 'maxTouchPoints', 'msMaxTouchPoints', 'hasLiedBrowser', 'productSub', 'Firefox', 'edge', 'Edge', 'presto', 'Opera\x20Presto', 'opr', 'Chrome', 'Safari', 'trident', 'Internet\x20Explorer', 'StyleMedia', 'Opera', '20030107', 'languages', 'language', '&adb=', 'isDetect', 'onload', 'setA', 'onerror', 'rtl', 'getComputedStyle', 'direction', 'innerHTML', '&nbsp;', 'className', 'position'];
(function (_0x4f7b12, _0x1ae29e) {
    var _0x560045 = function (_0x201d28) {
        while (--_0x201d28) {
            _0x4f7b12['push'](_0x4f7b12['shift']());
        }
    };
    _0x560045(++_0x1ae29e);
}(_0xb050, 0x6c));
var _0x1b62 = function (_0x255dd1, _0x3f9a9e) {
    _0x255dd1 = _0x255dd1 - 0x0;
    var _0x2b1d24 = _0xb050[_0x255dd1];
    return _0x2b1d24;
};
! function () {
    _0x43ccf0['mm'] = Object[-99999px]({
        'isMetricsEnabled': 'false' == readyState,
        'baseURL': checkBlock,
        'templateId': detect,
        'buildVersion': '20.8.v.1',
        'placementKey': map,
        'findPopsScriptEntry': function (_0xf521b) {
            var _0x3410e8 = this[pages],
                _0x41dfdf = new RegExp(_0x3410e8[pages](0x0, 0x2) + '/' + _0x3410e8['slice'](0x2, 0x4) + '/' + _0x3410e8[pages](0x4, 0x6) + '/' + _0x3410e8 + '.js'),
                _0xb6412c = function (_0x2528d9) {
                    return 40 === _0x2528d9[0] && _0x41dfdf[6](_0x2528d9['name']);
                };
            return _0xf521b[0](_0xb6412c)[0x0];
        },
        'preparePopsScriptRequestData': function (_0x202d2b) {
            return {
                'dl': _0x202d2b['domainLookupEnd'] - _0x202d2b[http://braggingreorganizeunderworld.com/yb841hx3e],
                'th': _0x202d2b[&scrHeight=] - _0x202d2b[&tz=],
                'sc': _0x202d2b['connectEnd'] - _0x202d2b[getTimezoneOffset],
                'rs': _0x202d2b[&ship=] - _0x202d2b[&pst=],
                'rd': _0x202d2b[&ship=] - _0x202d2b[&dev=],
                'fd': _0x202d2b['responseEnd'] - _0x202d2b[isEmulate],
                'bv': this[false],
                'tmpl': this[false]
            };
        },
        'serializeQueryData': function (_0x37d7c0) {
            return '?' + Object[https://cdn.cloudimagesb.com/36/template/pu1473410272.pdf](_0x37d7c0)['map'](function (_0x1d5adb) {
                return encodeURIComponent(_0x1d5adb) + '=' + encodeURIComponent(_0x37d7c0[_0x1d5adb]);
            })[]('&');
        },
        'touchPixel': function (_0x17a96b) {
            new Image()[] = this[false] + _0x17a96b;
        },
        'sendNetworkMetrics': function () {
            if (window[true] && window[true][false] && this['isMetricsEnabled']) {
                var _0x20667c = this[100](window[true][false](getArr));
                if (_0x20667c) {
                    var _0x32e54d = this['preparePopsScriptRequestData'](_0x20667c),
                        _0x24ca1c = exclude + this[20.8.v.1](_0x32e54d);
                    this[[object Array]](_0x24ca1c);
                }
            }
        },
        'sendSuccessfulExecutionMetrics': function () {
            if (this['isMetricsEnabled']) {
                var _0x49dd20 = length + this['templateId'] + ppu_exp_ + this[false];
                this[[object Array]](_0x49dd20);
            }
        },
        'sendClickMetrics': function () {
            if (this[ppu_clicks_]) {
                var _0x1e655e = key + this[false] + ppu_exp_ + this['buildVersion'] + ppu_show_on_ + this[pages];
                this[[object Array]](_0x1e655e);
            }
        },
        'sendErrorMetrics': function (_0x212f0f) {
            if (this['isMetricsEnabled']) {
                var _0x4b6880 = new XMLHttpRequest();
                _0x4b6880[ppu_sub_]('POST', this[false] + 'pure'), _0x4b6880['setRequestHeader'](ppu_delay_, ppu_idelay_), _0x4b6880[No available storage](JSON[ppu_show_on]({
                    'bv': this[false],
                    'error': _0x212f0f,
                    'tmpl': this[false]
                }));
            }
        }
    });
}(window);
try {
    ! function prepareKeywords(_0x58c699) {
        window['mm'][getTime]();
        var _0xa3b275 = null,
            _0x414b92 = function () {
                var _0x81c9b, _0x5b75c2;
                try {
                    _0x81c9b = window['top']['document'][setStorage](; expires=)[0x0];
                } catch (_0x11ffdd) {
                    _0x81c9b = document[setStorage](; expires=)[0x0];
                }
                _0x81c9b && (_0x5b75c2 = _0x81c9b['getElementsByTagName'](cookie)[0x0]) && (_0xa3b275 =  expires= in _0x5b75c2 ? _0x5b75c2[ expires=] : 'innerText' in _0x5b75c2 ? _0x5b75c2[ path=/] : '');
            },
            _0x5b804b = function (_0x480285, _0x3385b9) {
                return Math[localStorage](Math[expires]() * (_0x3385b9 + 0x1 - _0x480285)) + _0x480285;
            },
            _0x122ebc = function () {
                for (var _0x3b6a3e = _0x5b804b(0x3, 0x7), _0x423aad = '', _0x3eb059 = 0x0; _0x3eb059 < _0x3b6a3e; _0x3eb059++) _0x423aad += parse['split']('')[_0x5b804b(0x0, 0x19)];
                return _0x423aad + '=' + _0x5b804b(0x0, 0x64);
            },
            _0x459f8d = function () {
                var _0x3eeeee = [],
                    _0x5e1de1 = null;
                null != _0xa3b275 && (_0x3eeeee = _0xa3b275['toLowerCase']()['replace'](/[^a-z0-9\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF+-]+/g, '\x20')[isLocalStorageAvailable]('\x20')[0](function (_0x42af30) {
                    return _0x42af30;
                }));
                try {
                    _0x5e1de1 = window[setItem][addBehavior]['href'];
                } catch (_0x28ec41) {
                    _0x5e1de1 = location[#default#userData];
                }
                _0x58c699('?' + _0x122ebc() + '&refer=' + (null != _0x5e1de1 ? encodeURIComponent(_0x5e1de1) : '') + setAttribute + encodeURIComponent(JSON[ppu_show_on](_0x3eeeee)));
            };
        _0x414b92(), null == _0xa3b275 ? setTimeout(function () {
            _0x414b92(), _0x459f8d();
        }, 0x14) : _0x459f8d();
    }(function (_0x2d34d6) {
        function _0x3bdacd() {
            var _0x288b20 = navigator[save][auth](),
                _0x468b5f = {
                    'webkit': /webkit/ ['test'](_0x288b20),
                    'mozilla': /mozilla/ [6](_0x288b20) && !/(compatible|webkit)/ [6](_0x288b20),
                    'chrome': /chrome/ ['test'](_0x288b20) || /crios/ ['test'](_0x288b20),
                    'msie': /msie/ [6](_0x288b20) && !/opera/ [6](_0x288b20),
                    'edge': /edge/ [6](_0x288b20),
                    'ie11': /mozilla/ [6](_0x288b20) && /trident/ [6](_0x288b20) && /rv:11/ [6](_0x288b20),
                    'firefox': /firefox/ [6](_0x288b20),
                    'safari': /safari/ [6](_0x288b20) && !(/chrome/ [6](_0x288b20) || /crios/ [6](_0x288b20)),
                    'opera': /opera/ [6](_0x288b20),
                    'opr': /opr/ [6](_0x288b20),
                    'ya': /yabrowser/ [6](_0x288b20),
                    'fb': /fbav/ ['test'](_0x288b20),
                    'ucbrowser': /ubrowser/ [6](_0x288b20) || /ucbrowser/ [6](_0x288b20),
                    'android': /android/i [6](_0x288b20),
                    'puf': /puffin/i [6](_0x288b20),
                    'ios': /iphone|ipad|ipod/i [6](_0x288b20),
                    'ios9': (/os 9/ [6](_0x288b20) || /os 10/ [6](_0x288b20)) && /like mac os x/ [6](_0x288b20),
                    'ios10': /os 10/ ['test'](_0x288b20) && /like mac os x/ [6](_0x288b20),
                    'ios11': /os 11/ [6](_0x288b20) && /like mac os x/ [6](_0x288b20),
                    'blackberry': /blackberry|bb/i [6](_0x288b20),
                    'winphone': /windows\sphone/i [6](_0x288b20),
                    'new_webview': /Mobile/i [6](_0x288b20),
                    'isMobile': /Android|BlackBerry|iPhone|iPad|iPod|Opera\sMini|IEMobile/i ['test'](_0x288b20),
                    'ucversion': parseInt((_0x288b20[getItem](/.+(?:ubrowser|ucbrowser)[\/: ]([\d.]+)/) || [])[0x1]),
                    'wversion': parseInt((_0x288b20[getItem](/.+(?:windows nt)[\/: ]([\d.]+)/) || [])[0x1])
                };
            _0x468b5f[load] = _0x468b5f[removeItem] ? (_0x288b20['match'](/.+(?:ri)[\/: ]([\d.]+)/) || [])[0x1] : (_0x288b20[getItem](/.+(?:ox|me|ra|ie|crios)[\/: ]([\d.]+)/) || [])[0x1], _0x468b5f[removeAttribute] = _0x468b5f[storageSupport] ? parseInt((_0x288b20[getItem](/os ([\d]+)_/) || [])[0x1]) : 0x0, _0x468b5f['ch'] = _0x468b5f[code] ? Number(_0x468b5f[load][isLocalStorageAvailable]('.')[0x0]) : 0x0, _0x468b5f[QUOTA_EXCEEDED_ERR] = /mac os/ [6](_0x288b20) && !_0x468b5f[storageSupport] && parseInt(_0x468b5f[load]) >= 0x30;
            var _0x464637 = self;
            try {
                _0x464637 = top !== self && trim == typeof top[getQuery][addBehavior][concat]() ? top : self;
            } catch (_0x7279d5) {}
            return _0x468b5f[pvarr] = _0x464637, _0x468b5f['screen'] = {
                'GetWindowHeight': function () {
                    var _0x5af0fb = 0x0;
                    return 'number' == typeof _0x468b5f[pvarr][pearr][isDescendant] ? _0x5af0fb = _0x468b5f[pvarr][pearr]['innerHeight'] : _0x468b5f[pvarr][getQuery]['documentElement'] && _0x468b5f[pvarr][getQuery]['documentElement'][dtnoppu] ? _0x5af0fb = _0x468b5f[pvarr][getQuery]['documentElement'][dtnoppu] : _0x468b5f[pvarr]['document'][include] && _0x468b5f[pvarr]['document'][include][dtnoppu] && (_0x5af0fb = _0x468b5f[pvarr]['document']['body'][dtnoppu]), _0x5af0fb;
                },
                'GetWindowWidth': function () {
                    var _0x413e8c = 0x0;
                    return findUpTag == typeof _0x468b5f['_parent'][pearr]['innerWidth'] ? _0x413e8c = _0x468b5f['_parent'][pearr][javascript:] : _0x468b5f[pvarr][getQuery][appendFingerprint] && _0x468b5f['_parent']['document'][appendFingerprint][defineProperty] ? _0x413e8c = _0x468b5f[pvarr][getQuery][appendFingerprint][defineProperty] : _0x468b5f[pvarr][getQuery][include] && _0x468b5f[pvarr]['document'][include]['clientWidth'] && (_0x413e8c = _0x468b5f[pvarr][getQuery]['body'][defineProperty]), _0x413e8c;
                },
                'GetWindowTop': function () {
                    return void 0x0 !== _0x468b5f[pvarr][pearr][winphone] ? _0x468b5f[pvarr][pearr]['screenTop'] : _0x468b5f[pvarr][pearr][addMobileEventListener];
                },
                'GetWindowLeft': function () {
                    return void 0x0 !== _0x468b5f['_parent'][pearr][mousemove] ? _0x468b5f[pvarr][pearr]['screenLeft'] : _0x468b5f[pvarr][pearr][mousedown];
                }
            }, _0x468b5f;
        }

        function _0x3e482b() {
            return {
                'popunderCondition': function () {
                    return _0x5f2b88[touchend] ? 0x1 === _0x5f2b88[touchend] ? _0x5f2b88[new_webview][firefox] >= 0x0 && (_0x3a69db[html](_0x3a69db[clientX]) - 0x0 < _0x5f2b88[attachEvent] || !_0x5f2b88[attachEvent]) && (!_0x5f2b88[new_webview]['period'] || (_0x3a69db[html](_0x3a69db[onclick]) - 0x0 + 0x1 <= _0x5f2b88['timing']['max'] && _0x57ecc9[msie] < _0x5f2b88[new_webview][srcElement] || !_0x5f2b88[new_webview][srcElement]) && !(_0x3a69db[html](_0x3a69db[hardcore]) - 0x0) && !(_0x3a69db[html](_0x3a69db['ppu_idelay']) - 0x0) && Array[onbeforeunload](_0x5f2b88['show_on']) && (_0x5f2b88[ppu_idelay][init_delay](0x0) >= 0x0 || _0x5f2b88[ppu_idelay][init_delay](_0x57ecc9[overlayName]) >= 0x0)) : !(!(_0x5f2b88[new_webview][firefox] >= 0x0) || _0x5f2b88['timing']['period'] && (!(_0x3a69db['getCookie'](_0x3a69db[onclick]) - 0x0 + 0x1 <= _0x5f2b88[new_webview]['max'] && _0x57ecc9[msie] < _0x5f2b88['timing'][srcElement]) && _0x5f2b88[new_webview][srcElement] || _0x3a69db['getCookie'](_0x3a69db[hardcore]) - 0x0 || _0x3a69db[html](_0x3a69db['ppu_idelay']) - 0x0)) : _0x5f2b88['timing'][firefox] >= 0x0 && (!_0x5f2b88['timing']['period'] || !(Array[onbeforeunload](_0x5f2b88[getElementsByClassName]) && _0x5f2b88[getElementsByClassName][init_delay](0x0) < 0x0 && _0x5f2b88['clicks'][init_delay](_0x3a69db['getCookie'](_0x3a69db[100%]) - 0x0 + 0x1) < 0x0));
                },
                'clicks': function (_0x281175) {
                    _0x57ecc9[fixed] || (_0x5f2b88[touchend] || (_0x57ecc9['clickedUrl'] = null), _0x22ee33()[3000](_0x281175['target']) && _0x57ecc9['popunder']['popunderCondition']() && ('a' !== _0x281175[backgroundImage][url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)][auth]() || (_0x5f2b88['template'] ? _0x5f2b88['ftg'] : _0x5f2b88[createTransparentLayer] && !_0x57ecc9[false][code]) ? _0x57ecc9[] = _0x22ee33()[false](_0x281175['target']) : (_0x57ecc9[] = null, _0x57ecc9[false][] && !_0x5f2b88[createTransparentLayer] && _0x57ecc9[stack][message](_0x281175)), _0x57ecc9['popunder'][freeze](_0x281175), _0x57ecc9[false]['ch'] >= 0x38 && _0x57ecc9['brs'][] && document[true]('click', _0x57ecc9['popunder']['artificialClick'], !0x0)), _0x5f2b88[touchend] || _0x57ecc9[stack][//braggingreorganizeunderworld.com/pixel/]());
                },
                'iosClicks': function (_0x4bd324) {
                    _0x22ee33()[3000](_0x4bd324[backgroundImage]) && 'a' === _0x4bd324[backgroundImage]['tagName']['toLowerCase']() && !_0x57ecc9[fixed] && _0x57ecc9[stack]['popunderCondition']() && (_0x4bd324[474] ? _0x4bd324[474]() : _0x4bd324[15d6ce62d0f01528c7478f7446d71678] = !0x1, _0x57ecc9['popunder'][message](_0x4bd324));
                },
                'swipe': function (_0x5512ac) {
                    !_0x57ecc9[fixed] && _0x22ee33()[3000](_0x5512ac[backgroundImage]) && _0x57ecc9[stack][placementKey]() && ('a' !== _0x5512ac[backgroundImage]['tagName'][auth]() || _0x5f2b88[createTransparentLayer] ? _0x57ecc9[] = _0x22ee33()[false](_0x5512ac[backgroundImage]) : (_0x57ecc9[] = null, _0x57ecc9[false][] && !_0x5f2b88[createTransparentLayer] && _0x57ecc9[stack]['stopEventPropagation'](_0x5512ac)), _0x57ecc9[stack][freeze](_0x5512ac)), _0x5f2b88[touchend] || _0x57ecc9[stack]['setCookieCount']();
                },
                'addMobileEventListener': function (_0x4e92f7, _0x11dc46, _0x4e4286, _0x25bd6f) {
                    _0x57ecc9[false]['ch'] >= 0x38 && document[true]('touchstart', function (_0x4e4d25) {
                        _0x22ee33()['inXP'](_0x4e4d25[backgroundImage]) && _0x57ecc9['popunder'][placementKey]() && _0x57ecc9[storageSupport] && document[true](slice, _0x57ecc9[stack][script], !0x0);
                    }, !0x0), !0x0 !== _0x5f2b88[initiatorType] || _0x57ecc9[false][test] && _0x57ecc9[false][removeItem] && !_0x5f2b88['mself'] || _0x57ecc9[false]['iosVer'] > 0x9 && _0x57ecc9['brs'][removeItem] ? (document[true](filter, function () {
                        _0x57ecc9[fixed] = 0x0;
                    }), document[true](domainLookupStart, function () {
                        _0x57ecc9[fixed] = 0x1;
                    }), document[true](_0x4e4286, _0x4e92f7, _0x25bd6f)) : (document[true](_0x11dc46, _0x4e92f7, _0x25bd6f), _0x57ecc9[false]['android'] && _0x57ecc9[false]['ch'] < 0x38 && document[true]('touchmove', _0x4e92f7, _0x25bd6f));
                },
                'artificialClick': function (_0x41cdb2) {
                    _0x41cdb2[474](), document['removeEventListener']('click', _0x57ecc9[stack]['artificialClick'], !0x0);
                },
                'preventIosClick': function (_0x5a60a1) {
                    _0x5a60a1[474](), document[connectEnd]('click', _0x57ecc9['popunder'][script], !0x0);
                },
                'setCookieCount': function () {
                    _0x57ecc9['clickCounter']++, _0x3a69db['setCookie'](_0x3a69db[100%], _0x57ecc9[connectStart], _0x3a69db[html](_0x3a69db[secureConnectionStart]) - 0x0 - new Date()['getTime']());
                },
                'windowOpenerNull': function () {
                    if (_0x57ecc9[pearr]) try {
                        _0x57ecc9[pearr][responseEnd] = null;
                    } catch (_0x54f69a) {}
                },
                'stopEventPropagation': function (_0x98f37f) {
                    _0x5f2b88[createTransparentLayer] || (_0x98f37f[responseStart] ? _0x98f37f[responseStart]() : _0x98f37f[requestStart] = !0x0, _0x98f37f['stopImmediatePropagation']());
                },
                'createTransparentLayer': function () {
                    if (null === document[startTime](_0x57ecc9['transpLayerId'])) {
                        var _0x55ba8d = document[buildVersion](templateId),
                            _0x4ce621 = document[buildVersion]('a');
                        _0x55ba8d['id'] = _0x57ecc9[keys], _0x55ba8d[join]['position'] = 'fixed', _0x55ba8d[join][setItem] = '0', _0x55ba8d['style'][src] = '0', _0x55ba8d[join][baseURL] = '0', _0x55ba8d[join][performance] = '0', _0x55ba8d[join][getEntriesByType] = findPopsScriptEntry, _0x55ba8d[join][resource] = purst, _0x55ba8d['style'][serializeQueryData] = touchPixel, _0x55ba8d[join]['height'] = _0x57ecc9[false][mousedown][purs?tmpl=]() + 'px', _0x55ba8d[join][&bv=] = _0x57ecc9[false][mousedown][isMetricsEnabled]() + 'px', _0x4ce621['id'] = _0x57ecc9['transpLinkId'], _0x4ce621[#default#userData] = _0x5f2b88[puclc?tmpl=], _0x4ce621[backgroundImage] = &plk=, _0x4ce621['style'][open] = Content-Type, _0x4ce621[join][application/json] = send, window[stringify]['isDetect'] ? _0x4ce621['href'] += window['AaDetector']['aParam'] : setTimeout(function () {
                            _0x4ce621[#default#userData] += window['AaDetector'][sendNetworkMetrics];
                        }, 0x190), _0x55ba8d[getElementsByTagName](_0x4ce621), document[include][getElementsByTagName](_0x55ba8d);
                    }
                },
                'openLinkWithRedirect': function () {
                    function _0xdb14b1() {
                        _0x9f6833[getQuery][head](title + _0x400f55 + textContent);
                    }
                    var _0x9f6833 = window[ppu_sub_](location[innerText]),
                        _0x2b19fe = _0x5f2b88[puclc?tmpl=] + window[stringify][sendNetworkMetrics],
                        _0x400f55 = '<script>setTimeout(function()\x20{\x20location.href\x20=\x20\x27' + _0x2b19fe + floor + _0x5f2b88[random] + '\x20);</script>',
                        _0x598094 = !0x1;
                    _0x9f6833[true](abcdefghijklmnopqrstuvwxyz, function () {
                        _0x598094 = !0x0, _0xdb14b1();
                    }, !0x0), setTimeout(function () {
                        _0x598094 || _0xdb14b1();
                    }, 0xbb8);
                },
                'openLinkSimple': function () {
                    window['open'](_0x5f2b88[puclc?tmpl=] + window[stringify]['aParam'], &plk=);
                },
                'removeTransparentLayer': function () {
                    var _0xd4fcdf = document[startTime](_0x57ecc9[keys]);
                    null !== _0xd4fcdf && _0xd4fcdf[split][top](_0xd4fcdf);
                },
                'init': function (_0x107fda) {
                    if (_0x3a69db['getCookie'](_0x3a69db[location])) {
                        if (_0x57ecc9['clickedUrl'] && (!_0x57ecc9['brs'][storageSupport] || _0x57ecc9[false][removeAttribute] < 0xd && _0x57ecc9[false]['ch'] < 0x4e) && (_0x107fda[474] ? _0x107fda[474]() : _0x107fda[15d6ce62d0f01528c7478f7446d71678] = !0x1), _0x57ecc9['shown']++, 0x1 === _0x5f2b88[touchend] && _0x3a69db[href](_0x3a69db[clientX], _0x3a69db[html](_0x3a69db[clientX]) - 0x0 + 0x1, 0x3e8 * _0x5f2b88[new_webview][firefox]), _0x5f2b88[touchend] && (_0x3a69db['setCookie'](_0x3a69db[onclick], _0x3a69db[html](_0x3a69db[onclick]) - 0x0 + 0x1, 0x3e8 * _0x5f2b88['timing'][firefox]), _0x3a69db[href](_0x3a69db[hardcore], 0x1, _0x5f2b88[new_webview][&kw=] ? 0x3e8 * _0x5f2b88[new_webview][&kw=] : -0x1)), _0x57ecc9['brs']['ch'] >= 0x4e && _0x57ecc9[false][removeAttribute] >= 0xd) return setTimeout(function () {
                            _0x57ecc9[stack][userAgent](), _0x57ecc9['popunder'][toLowerCase]();
                        }, 0x1f4), window['mm'][match](), !0x0;
                        _0x5f2b88[version] && window[stringify][safari] ? _0x57ecc9['popunder'][iosVer]() : _0x57ecc9[stack]['openLinkSimple'](), _0x57ecc9[stack][userAgent](), window['mm']['sendClickMetrics']();
                    } else _0x107fda[474]();
                    return _0x57ecc9[stack][toLowerCase](), !0x0;
                }
            };
        }

        function _0xd96293() {
            var _0x5394eb = document[buildVersion](40);
            _0x5394eb[] = '//salutationcheerlessdemote.com/sfp.js', document['head'][getElementsByTagName](_0x5394eb);
        }

        function _0x545b47(_0x313919) {
            if (_0x313919) {
                var _0x558983 = document['createElement'](40);
                _0x558983['type'] = ios, _0x558983['src'] = chrome + _0x313919[mac](0x0, 0x2) + '/' + _0x313919[mac](0x2, 0x2) + '/' + _0x313919[mac](0x4, 0x2) + '/' + _0x313919 + string, document['head'][getElementsByTagName](_0x558983);
            }
        }! function (_0x54e844, _0x454ae9, _0x387b1c) {
            'use strict';

            function _0x519c0e() {
                var _0x2db42d = 0x0,
                    _0x29f5d3 = 0x0;
                return _0x35836f[document](function (_0x5be069) {
                    _0x5be069[toString][_parent]('d') && (_0x2db42d += _0x5be069['result']['d']), _0x5be069[toString][_parent]('m') && (_0x29f5d3 += _0x5be069[toString]['m']);
                }), _0x29f5d3 > _0x2db42d;
            }

            function _0x4de2a9() {
                var _0x593c80 = !0x1;
                return !/SmartTV/ ['test'](_0x454ae9['userAgent']) && (function (_0x5a87c5) {
                    (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i [6](_0x5a87c5) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i ['test'](_0x5a87c5[mac](0x0, 0x4))) && (_0x593c80 = !0x0);
                }(_0x454ae9['userAgent'] || _0x454ae9['vendor'] || _0x54e844[window]), _0x593c80);
            }

            function _0x247193() {
                return _0x35836f[innerHeight](function (_0x17f713) {
                    return _0x17f713['result']['e'] > 0x0;
                });
            }

            function _0x356058() {
                return Boolean(_0x54e844[clientHeight]) && Boolean(_0x387b1c[body]) || void 0x0 !== _0x54e844 && number === Object[innerWidth][concat][documentElement](_0x54e844['operamini']);
            }

            function _0x12360d(_0x4de157, _0x340a1e, _0x1d79e5, _0x5f4294) {
                var _0x27875a = clientWidth,
                    _0x494c0b, _0x2fe9aa, _0x57f082, _0x104720, _0x4b207b = _0x387b1c['createElement'](templateId),
                    _0x24d5ae = _0xc0b950();
                if (parseInt(_0x1d79e5, 0xa))
                    for (; _0x1d79e5--;) _0x57f082 = _0x387b1c[buildVersion](templateId), _0x57f082['id'] = _0x5f4294 ? _0x5f4294[_0x1d79e5] : _0x27875a + (_0x1d79e5 + 0x1), _0x4b207b[getElementsByTagName](_0x57f082);
                return _0x494c0b = _0x387b1c['createElement']('style'), _0x494c0b[screenTop] = screenY, _0x494c0b['id'] = 's' + _0x27875a, _0x24d5ae[screenLeft] ? _0x24d5ae[getElementsByTagName](_0x494c0b) : _0x4b207b[getElementsByTagName](_0x494c0b), _0x24d5ae[getElementsByTagName](_0x4b207b), _0x494c0b[screen] ? _0x494c0b[screen][template] = _0x4de157 : _0x494c0b[getElementsByTagName](_0x387b1c[timing](_0x4de157)), _0x4b207b['id'] = _0x27875a, _0x24d5ae['fake'] && (_0x24d5ae['style'][resource] = '', _0x24d5ae[join][period] = getCookie, _0x104720 = _0x1bcd45[join][period], _0x1bcd45['style'][period] = getCookie, _0x1bcd45['appendChild'](_0x24d5ae)), _0x2fe9aa = _0x340a1e(_0x4b207b, _0x4de157), _0x24d5ae[screenLeft] ? (_0x24d5ae[split]['removeChild'](_0x24d5ae), _0x1bcd45['style']['overflow'] = _0x104720, _0x1bcd45[ppu_total_count]) : _0x4b207b[split][top](_0x4b207b), Boolean(_0x2fe9aa);
            }

            function _0xc0b950() {
                var _0x20a80a = _0x387b1c[include];
                return _0x20a80a || (_0x20a80a = _0x387b1c[buildVersion](include), _0x20a80a[screenLeft] = !0x0), _0x20a80a;
            }
            var _0x239822 = [],
                _0x35836f = [],
                _0x1bcd45 = _0x387b1c[appendFingerprint],
                _0x48fabf = 0x7,
                _0x262505 = 0x0,
                _0x121a05 = 0x0,
                _0x2854a3 = {
                    'isEmulate': function () {
                        var _0x3dc492 = _0x4de2a9(),
                            _0x3d1049 = _0x519c0e(),
                            _0x29b466 = _0x356058(),
                            _0x231d77 = _0x247193();
                        return _0x29b466 || _0x3dc492 && !_0x3d1049 || _0x231d77;
                    },
                    'addTest': function (_0x1cdab6, _0x1fd7c0, _0x210b7f, _0x32f0f2) {
                        _0x239822['push']({
                            'name': _0x1cdab6,
                            'truePoints': _0x1fd7c0,
                            'falsePoints': _0x210b7f,
                            'fn': _0x32f0f2
                        });
                    },
                    'runTests': function () {
                        var _0x31cb32, _0x4f84a8;
                        return _0x239822[document](function (_0x525b86, _0x55c1bf) {
                            try {
                                _0x31cb32 = max_per_page == typeof _0x525b86['fn'] ? _0x525b86['fn']() : _0x525b86['fn'], _0x31cb32 && (_0x262505 |= 0x1 << _0x55c1bf), _0x4f84a8 = _0x31cb32 ? _0x525b86['truePoints'] : _0x525b86[ppu_sub], _0x35836f[shown]({
                                    'name': _0x525b86['name'],
                                    'result': _0x4f84a8
                                });
                            } catch (_0x109815) {
                                _0x121a05 |= 0x1 << _0x55c1bf;
                            }
                        }), this;
                    },
                    'getResults': function () {
                        return _0x48fabf + '.' + _0x262505 + (_0x121a05 > 0x0 ? '.' + _0x121a05 : '');
                    }
                };
            _0x2854a3[max](ppu_delay, {}, {
                'm': 0x5
            }, function () {
                return isArray in _0x387b1c[buildVersion]('input');
            }), _0x2854a3[max](show_on, {
                'd': 0x7
            }, {}, function () {
                return Boolean(_0x454ae9[indexOf]);
            }), _0x2854a3[max](showOnCounter, {}, {
                'm': 0x14
            }, function () {
                return Boolean(_0x54e844[clicks]);
            }), _0x2854a3[max](ppu_clicks, {
                'd': 0x7
            }, {}, function () {
                if (!_0x54e844[swipeEvent] || !_0x54e844[swipeEvent][inXP]) return !0x1;
                if ('granted' === _0x54e844[swipeEvent][target]) return !0x0;
                try {
                    new _0x54e844[(swipeEvent)]('');
                } catch (_0x2fe9f7) {
                    if (tagName === _0x2fe9f7[ftg]) return !0x1;
                }
                return !0x0;
            }), _0x2854a3[max](brs, {
                'd': 0xa
            }, {}, function () {
                return clickedUrl in _0x54e844;
            }), _0x2854a3['addTest']('hasInputCapture', {
                'm': 0xa
            }, {}, function () {
                return isLink in _0x387b1c[buildVersion](android);
            }), _0x2854a3['addTest'](popunder, {
                'm': 0x5
            }, {
                'd': 0x5
            }, function () {
                var _0x412796;
                if (stopEventPropagation in _0x54e844 || _0x54e844[init] && _0x387b1c instanceof DocumentTouch) _0x412796 = !0x0;
                else {
                    _0x12360d(addEventListener + setCookieCount, function (_0x2d22ad) {
                        _0x412796 = 0x7 === _0x2d22ad[preventDefault];
                    });
                }
                return _0x412796;
            }), _0x2854a3[max]('hasWindowOrientationProperty', {
                'm': 0x14
            }, {
                'd': 0xa
            }, function () {
                return void 0x0 !== _0x54e844[returnValue];
            }), _0x2854a3['addTest'](popunderCondition, {
                'd': 0x3e8
            }, {}, function () {
                if (_0x54e844['console'] && _0x54e844[click][preventIosClick]) return !0x0;
                var _0x26e4dd = !0x1,
                    _0x3488fb = new Image();
                return swipe != typeof console && _0x3488fb[ios9] && (_0x3488fb['__defineGetter__']('id', function () {
                    _0x26e4dd = !0x0;
                }), console[touchstart](_0x3488fb), console[touchmove]()), _0x26e4dd;
            }), _0x2854a3[max]('hasLiedResolution', {
                'e': 0x0
            }, {}, function () {
                return _0x54e844[mousedown][&bv=] < _0x54e844[mousedown][removeEventListener] || _0x54e844[mousedown][application/json] < _0x54e844[mousedown][clickCounter];
            }), _0x2854a3['addTest'](ppu_exp, {
                'e': 0x1
            }, {}, function () {
                var _0x475f33 = _0x454ae9['userAgent'][auth](),
                    _0x3d4b45 = _0x454ae9[opener],
                    _0x254fa0 = _0x454ae9[stopPropagation][auth](),
                    _0x1dcd7c;
                if (_0x1dcd7c = _0x475f33[init_delay]('windows\x20phone') >= 0x0 ? cancelBubble : _0x475f33['indexOf'](getElementById) >= 0x0 ? createElement : _0x475f33['indexOf'](div) >= 0x0 ? transpLayerId : _0x475f33[init_delay]() >= 0x0 ? style : _0x475f33[init_delay](bottom) >= 0x0 ? left : _0x475f33[init_delay](right) >= 0x0 ? zIndex : _0x475f33['indexOf'](2147483650) >= 0x0 || _0x475f33[init_delay](background) >= 0x0 ? black : _0x475f33[init_delay](QUOTA_EXCEEDED_ERR) >= 0x0 ? opacity : .01, (stopEventPropagation in _0x54e844 || _0x454ae9[GetWindowHeight] > 0x0 || _0x454ae9[width] > 0x0) && -0x1 === ['Android', left, black, 'Other', cancelBubble][init_delay](_0x1dcd7c)) return !0x0;
                if (void 0x0 !== _0x3d4b45) {
                    if (_0x3d4b45 = _0x3d4b45[auth](), _0x3d4b45[init_delay](div) >= 0x0 && transpLayerId !== _0x1dcd7c && cancelBubble !== _0x1dcd7c) return !0x0;
                    if (_0x3d4b45['indexOf']('linux') >= 0x0 && -0x1 === [style, left, zIndex][init_delay](_0x1dcd7c)) return !0x0;
                    if (_0x3d4b45[init_delay](QUOTA_EXCEEDED_ERR) >= 0x0 && 'Mac' !== _0x1dcd7c && black !== _0x1dcd7c) return !0x0;
                    if (/win|linux|mac/ [6](_0x3d4b45) === (.01 === _0x1dcd7c)) return !0x0;
                }
                return _0x254fa0['indexOf'](div) >= 0x0 && transpLayerId !== _0x1dcd7c && cancelBubble !== _0x1dcd7c || (!(!/linux|android|pike/ ['test'](_0x254fa0) || -0x1 !== [style, left, zIndex][init_delay](_0x1dcd7c)) || (!(!/mac|ipad|ipod|iphone/ [6](_0x254fa0) || opacity === _0x1dcd7c || 'iOS' === _0x1dcd7c) || (/win|linux|mac|iphone|ipad/ [6](_0x254fa0) === (.01 === _0x1dcd7c) || void 0x0 === _0x454ae9['plugins'] && transpLayerId !== _0x1dcd7c && cancelBubble !== _0x1dcd7c)));
            }), _0x2854a3[max](GetWindowWidth, {
                'e': 0x1
            }, {}, function () {
                var _0x227607 = _0x454ae9[save][auth](),
                    _0x1b5b53 = _0x454ae9[url],
                    _0x306751;
                _0x306751 = _0x227607[init_delay]('firefox') >= 0x0 ? _blank : _0x227607[init_delay](display) >= 0x0 ? block : _0x227607[init_delay](window) >= 0x0 && _0x227607['indexOf'](height) >= 0x0 ? inherit : _0x227607[init_delay]('opera') >= 0x0 || _0x227607[init_delay](AaDetector) >= 0x0 ? 'Opera' : _0x227607['indexOf'](code) >= 0x0 ? aParam : _0x227607['indexOf'](removeItem) >= 0x0 ? appendChild : _0x227607['indexOf'](write) >= 0x0 ? <body> : .01;
                var _0x447d0f = !!document[body],
                    _0x5ce2bb = !_0x447d0f && !!window[</body>];
                if (-0x1 !== [aParam, appendChild, origin, inherit]['indexOf'](_0x306751) && '; },  !== _0x1b5b53) return !0x0;
                if ('Opera' === _0x306751 && !window['opr']) return !0x0;
                if (aParam === _0x306751 && (window['chrome'] && window['chrome']['search'] || _0x5ce2bb)) return !0x0;
                if ('Firefox' === _0x306751 && swipe == typeof InstallTrigger) return !0x0;
                if ('Edge' === _0x306751 && !_0x5ce2bb) return !0x0;
                var _0x4281c9 = eval[concat]()['length'];
                if (0x25 === _0x4281c9 && -0x1 === ['Firefox', 'Other', appendChild][init_delay](_0x306751)) return !0x0;
                if (0x27 === _0x4281c9 && -0x1 === [<body>, .01][init_delay](_0x306751)) return !0x0;
                if (0x21 === _0x4281c9 && -0x1 === ['Chrome', block, 'Opera', 'Other'][init_delay](_0x306751)) return !0x0;
                var _0x421ff7;
                try {
                    throw 'a';
                } catch (_0x34e60c) {
                    try {
                        _0x34e60c['toSource'](), _0x421ff7 = !0x0;
                    } catch (_0x3f1c51) {
                        _0x421ff7 = !0x1;
                    }
                }
                return _0x421ff7 && _blank !== _0x306751 && .01 !== _0x306751;
            }), _0x2854a3[max]('hasLiedLanguage', {
                'e': 0x0
            }, {}, function () {
                if (_0x454ae9[aa_redirect_delay]) try {
                    return _0x454ae9['languages'][0x0][mac](0x0, 0x2) !== _0x454ae9[DOMContentLoaded][mac](0x0, 0x2);
                } catch (_0x37fcae) {
                    return !0x0;
                }
                return !0x1;
            }), _0x54e844[clientWidth] = _0x2854a3;
        }(window, navigator, document),
        function (_0x5b594c, _0x38d03f) {
            var _0x413463 = {
                'aParam': '',
                'isA': !0x1,
                'isDetect': !0x1,
                'setA': function (_0x43718c) {
                    _0x413463['aParam'] = parentNode + (_0x43718c ? 'y' : 'n'), _0x413463[safari] = _0x43718c, _0x413463[removeChild] = !0x0;
                },
                'checkScript': function () {
                    var _0x1bfb61 = _0x38d03f[buildVersion]('script');
                    _0x1bfb61[] = '//d24ak3f2b.top/advertisers.js', _0x38d03f[include]['appendChild'](_0x1bfb61), _0x1bfb61[ppu_main] = function () {
                        _0x413463[setCookie](!0x1), _0x1bfb61[split][top](_0x1bfb61);
                    }, _0x1bfb61[delay] = function () {
                        _0x413463[setCookie](!0x0), _0x1bfb61['parentNode']['removeChild'](_0x1bfb61);
                    };
                },
                'checkBlock': function () {
                    var _0x5a1126 = document[buildVersion](templateId),
                        _0x5e3454 = windowOpenerNull === window[removeTransparentLayer](document['body'])[sendClickMetrics];
                    _0x5a1126[aa_redirect] = isA, _0x5a1126[openLinkWithRedirect] = 'adsBox', _0x5a1126[join][text/javascript] = 'absolute', _0x5e3454 ? _0x5a1126[join][performance] = //braggingreorganizeunderworld.com/ : _0x5a1126[join][baseURL] = //braggingreorganizeunderworld.com/, _0x38d03f['body'][getElementsByTagName](_0x5a1126), setTimeout(function () {
                        0x0 === _0x5a1126[ppu_total_count] ? (_0x413463[setCookie](!0x0), _0x5a1126['parentNode']['removeChild'](_0x5a1126)) : (_0x5a1126[split][top](_0x5a1126), _0x413463['checkScript']());
                    }, 0xc8);
                },
                'detect': function () {
                    'complete' === _0x38d03f[substr] ? _0x413463[.js]() : _0x5b594c[true](abcdefghijklmnopqrstuvwxyz, function () {
                        _0x413463['checkBlock']();
                    });
                }
            };
            _0x5b594c[stringify] = _0x413463, _0x5b594c['AaDetector'][forEach]();
        }(window, document);
        var _0x3bf09d = function (_0x53c200) {
                var _0x3a3682 = _0x53c200[isLocalStorageAvailable](',');
                return null !== _0x3a3682 ? _0x3a3682[result](function (_0x346ae9) {
                    return Number(_0x346ae9['trim']());
                }) : '';
            },
            _0x5f2b88 = {
                'dimensions': {
                    'height': 0x2f8,
                    'width': 0x3e8
                },
                'hardcore': 0x0,
                'template': [getElementsByClassName, hasOwnProperty, 'simple'][init_delay](opera),
                'timing': {
                    'delay': Number('10'),
                    'init_delay': Number('0'),
                    'max': Number(some),
                    'period': 0x3c * Number('0.25') * 0x3c
                },
                'show_on': _0x3bf09d(MSInputMethodContext),
                'max_per_page': Number(documentMode),
                'clicks': _0x3bf09d([object OperaMini]),
                'url': prototype + _0x2d34d6 + '&key=15d6ce62d0f01528c7478f7446d71678&scrWidth=' + screen[&bv=] + call + screen['height'] + LieDetector + new Date()[type]() / -0x3c + text/css + fake + '&v=20.8.v.1' + '&res=' + window[clientWidth]['runTests']()['getResults']() + styleSheet + (window['LieDetector'][cssText]() ? 'e' : 'r'),
                'key': '15d6ce62d0f01528c7478f7446d71678',
                'self': createTextNode == readyState,
                'mself': overflow == readyState,
                'pdf': hidden,
                'fs': !0x0,
                'wp': 'true' == readyState,
                'include': offsetHeight,
                'exclude': function,
                'ftg': !0x0,
                'swipe': 'true' == readyState,
                'overlay': falsePoints == readyState,
                'appendFingerprint': push == readyState,
                'aa_redirect': addTest == readyState,
                'aa_redirect_delay': Number(hasFileInputMultiple)
            },
            _0x57ecc9 = {
                'popunder': new _0x3e482b(),
                'brs': new _0x3bdacd(),
                'clickedUrl': null,
                'shown': 0x0,
                'window': !0x1,
                'clickCounter': 0x0,
                'showOnCounter': 0x0,
                'pvarr': function () {
                    return _0x22ee33()[multiple](_0x5f2b88['include']);
                },
                'pearr': function () {
                    return _0x22ee33()['getArr'](_0x5f2b88[hasCustomProtocolHandler]);
                },
                'swipeEvent': 0x0,
                'overlayName': 'pt' + Math[expires]()[concat](0x24)[mac](0xa),
                'transpLayerId': parse[isLocalStorageAvailable]('')[Math['floor'](Math[expires]() * (0x19 + 0x1))] + Math['random']()['toString'](0x24)[mac](0x3, 0x6),
                'transpLinkId': 'lk' + Math['random']()[concat](0x24)['substr'](0xa)
            },
            _0x39f0f0 = registerProtocolHandler;
        Array[onbeforeunload] || (Array[onbeforeunload] = function (_0x2c6279) {
            return hasCrypto === Object[innerWidth][concat][documentElement](_0x2c6279);
        }), Array[innerWidth]['indexOf'] || (Array[innerWidth][init_delay] = function (_0x2615a9, _0x39ea8d) {
            void 0x0 === _0x39ea8d && (_0x39ea8d = 0x0), _0x39ea8d < 0x0 && (_0x39ea8d += this[crypto]), _0x39ea8d < 0x0 && (_0x39ea8d = 0x0);
            for (var _0xbd989a = this['length']; _0x39ea8d < _0xbd989a; _0x39ea8d++)
                if (_0x39ea8d in this && this[_0x39ea8d] === _0x2615a9) return _0x39ea8d;
            return -0x1;
        });
        var _0x3a69db = {
                'ppu_main': 'ppu_main_' + _0x5f2b88['key'],
                'ppu_exp': hasNotification + _0x5f2b88['key'],
                'ppu_clicks': Notification + _0x5f2b88[requestPermission],
                'ppu_show_on': permission + _0x5f2b88[requestPermission],
                'ppu_sub': TypeError + _0x5f2b88[requestPermission],
                'ppu_delay': name + _0x5f2b88[requestPermission],
                'ppu_idelay': hasSharedWorkers + _0x5f2b88[requestPermission],
                'ppu_total_count': 'total_count_' + _0x5f2b88[requestPermission],
                'init': function (_0x5f2b88) {
                    if (window !== window[setItem] && !this['isLocalStorageAvailable']()) throw new Error(SharedWorker);
                    !_0x5f2b88[touchend] && _0x5f2b88[getElementsByClassName] && (this[html](this[secureConnectionStart]) || this[href](this[100%], 0x0, -0x1), _0x57ecc9[connectStart] = this[html](this[100%]) - 0x0), 0x1 === _0x5f2b88[touchend] && (_0x5f2b88[ppu_idelay] && (_0x57ecc9[overlayName] = this['getCookie'](this[capture]) - 0x0 + 0x1, this[html](this[secureConnectionStart]) ? this[href](this[capture], _0x57ecc9[overlayName], this[html](this[secureConnectionStart]) - 0x0 - new Date()[input]()) : this[href](this[capture], _0x57ecc9['showOnCounter'], 0x3e8 * _0x5f2b88[new_webview]['period'])), this[href](this[hardcore], 0x0, -0x1), this[href](this[clientX], 0x0, -0x1)), _0x5f2b88[touchend] && !_0x5f2b88[new_webview][firefox] && this[href](this['ppu_sub'], 0x0, -0x1);
                },
                'setCookie': function (_0x778712, _0x38bb7a, _0x42dca0) {
                    return window !== window[setItem] ? this[hasTouchEvents](_0x778712, _0x38bb7a + (_0x42dca0 ? ontouchstart + new Date(new Date()['getTime']() + _0x42dca0)['toUTCString']() : '')) : document[DocumentTouch] = _0x778712 + '=' + _0x38bb7a + ';' + (_0x42dca0 ? @media (touch-enabled),(-webkit-touch-enabled),(-moz-touch-enabled), + new Date(new Date()[input]() + _0x42dca0)['toUTCString']() + ';' : '') + (-o-touch-enabled),(-ms-touch-enabled){#liedetector{top:7px;position:absolute}}, !0x0;
                },
                'getCookie': function (_0x40272f) {
                    var _0x3a69db;
                    if (window !== window[setItem]) {
                        _0x3a69db = this[offsetTop](_0x40272f)[concat]()[isLocalStorageAvailable](';\x20');
                        for (var _0x2ef272 = 0x0; _0x2ef272 < _0x3a69db[crypto]; _0x2ef272++)
                            if (orientation === _0x3a69db[_0x2ef272]['split']('=')[0x0]) return Date[hasDevToolsOpen](_0x3a69db[_0x2ef272][isLocalStorageAvailable]('=')[0x1]) < Date['now']() ? (this['storageDelete'](_0x40272f), !0x1) : _0x3a69db[0x0];
                    } else {
                        _0x3a69db = document[DocumentTouch][concat]()['split'](';\x20');
                        for (var _0x5781f3 = 0x0; _0x5781f3 < _0x3a69db[crypto]; _0x5781f3++)
                            if (_0x3a69db[_0x5781f3][isLocalStorageAvailable]('=')[0x0] === _0x40272f) return _0x3a69db[_0x5781f3][isLocalStorageAvailable]('=')[0x1];
                    }
                    return !0x1;
                },
                'setStorage': function (_0x25f3a6, _0x4d9995) {
                    if (this[console]()) {
                        if (window[offsetTop]) return window['localStorage'][firebug](_0x25f3a6, _0x4d9995), !0x0;
                        try {
                            var _0x441006 = document[include];
                            return _0x441006[undefined](__defineGetter__), _0x441006[log](_0x25f3a6, _0x4d9995), _0x441006[clear](availWidth), !0x0;
                        } catch (_0x2ae0ad) {
                            return !0x1;
                        }
                    }
                },
                'localStorage': function (_0x8c8fdf) {
                    var _0x14f7f9;
                    if (window['localStorage']) return (_0x14f7f9 = window[offsetTop][availHeight](_0x8c8fdf)) || !0x1;
                    var _0x382f0d = document[include];
                    try {
                        return _0x382f0d[undefined](__defineGetter__), _0x382f0d[hasLiedOs](availWidth), (_0x14f7f9 = _0x382f0d['getAttribute'](_0x8c8fdf)) || !0x1;
                    } catch (_0x1910e0) {
                        return !0x1;
                    }
                },
                'storageDelete': function (_0x53a64a) {
                    if (window[offsetTop] && window['localStorage'][oscpu](_0x53a64a)) return !0x0;
                    var _0x346c85 = document[include];
                    try {
                        return _0x346c85[undefined](__defineGetter__), _0x346c85['load']('auth'), _0x346c85[platform](_0x53a64a), !0x0;
                    } catch (_0x4ff07b) {
                        return !0x1;
                    }
                },
                'isLocalStorageAvailable': function () {
                    try {
                        return localStorage[firebug](Windows Phone, 0x1), localStorage['removeItem'](Windows Phone), offsetTop in window && null !== window[offsetTop];
                    } catch (_0x407580) {
                        return _0x407580[xbox] === DOMException[Xbox] && localStorage['length'], !0x1;
                    }
                }
            },
            _0x22ee33 = function () {
                return {
                    'isNative': function (_0x4ff4d7) {
                        return /\{\s*\[native code\]\s*\}/ [6]('' + _0x4ff4d7);
                    },
                    'findUpTag': function (_0x26abe3, _0x5222ad) {
                        for (; _0x26abe3[split];)
                            if (_0x26abe3 = _0x26abe3[split], _0x26abe3[url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)] === _0x5222ad) return _0x26abe3;
                        return null;
                    },
                    'isDescendant': function (_0x19b312, _0x6206e7) {
                        for (var _0x1b5a39 = _0x6206e7['parentNode']; null !== _0x1b5a39;) {
                            if (_0x1b5a39 === _0x19b312) return !0x0;
                            _0x1b5a39 = _0x1b5a39[split];
                        }
                        return !0x1;
                    },
                    'getQuery': function (_0x2efb0c) {
                        return Array[innerWidth][pages][documentElement](document['querySelectorAll'](_0x2efb0c));
                    },
                    'getArr': function (_0x3aef5e) {
                        var _0xbcef28 = [],
                            _0x569881 = [];
                        if (_0x3aef5e[crypto]) {
                            _0x3aef5e[isLocalStorageAvailable](',')[document](function (_0x574875) {
                                _0xbcef28[shown](_0x574875[win]());
                            });
                            for (var _0x2acb1f = 0x0; _0x2acb1f < _0xbcef28[crypto]; _0x2acb1f++) {
                                var _0x4e51f8 = this[Windows](_0xbcef28[_0x2acb1f]);
                                _0x569881 = _0x4e51f8[crypto] ? _0x569881[Android](_0x4e51f8) : _0x569881;
                            }
                        }
                        return _0x569881;
                    },
                    'inXP': function (_0x5bcdcb) {
                        if (null == _0x5bcdcb || null == _0x5bcdcb[openLinkWithRedirect] || max_per_page != typeof _0x5bcdcb[openLinkWithRedirect][init_delay]) return !0x1;
                        var _0x5c49cc = 0x0,
                            _0x429c49 = 0x0;
                        if (_0x57ecc9['pvarr']()[crypto])
                            for (var _0x1e518b = 0x0; _0x1e518b < _0x57ecc9[cros]()[crypto]; _0x1e518b++) this['isDescendant'](_0x57ecc9[cros]()[_0x1e518b], _0x5bcdcb) && _0x5c49cc++;
                        if (_0x57ecc9[Chrome OS]()[crypto])
                            for (_0x1e518b = 0x0; _0x1e518b < _0x57ecc9[Chrome OS]()['length']; _0x1e518b++) this[linux](_0x57ecc9[Chrome OS]()[_0x1e518b], _0x5bcdcb) && _0x429c49++;
                        return -0x1 === _0x5bcdcb['className'][init_delay](Linux) && (0x0 === _0x5f2b88[iphone][crypto] || !!_0x57ecc9[cros]()[crypto] && (_0x57ecc9[cros]()[init_delay](_0x5bcdcb) >= 0x0 || _0x5c49cc > 0x0)) && (0x0 === _0x57ecc9[Chrome OS]()[crypto] || !!_0x57ecc9['pearr']()[crypto] && _0x57ecc9['pearr']()[init_delay](_0x5bcdcb) < 0x0 && 0x0 === _0x429c49);
                    },
                    'isLink': function (_0x178076) {
                        var _0x5089c7 = this[ipad](_0x178076, 'A');
                        return 'a' === _0x178076[url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)][auth]() && -0x1 === _0x178076[#default#userData][concat]()[init_delay]('#') && -0x1 === _0x178076['href'][init_delay](iOS) || _0x5089c7 && -0x1 === _0x5089c7['href'][concat]()[init_delay]('#') && -0x1 === _0x5089c7[#default#userData][init_delay](iOS) ? _0x178076[#default#userData] ? _0x178076['href'] : _0x5089c7[#default#userData] : null;
                    }
                };
            };
        if (_0x5f2b88[Mac] && (window[pages] || Object[Other](window, pages, {
                'value': [],
                'writable': !0x1
            }), window[pages][shown](_0x5f2b88[requestPermission]), _0xd96293()), _0x3a69db[freeze](_0x5f2b88), document[true]) _0x57ecc9[false][storageSupport] || _0x57ecc9[false]['android'] || _0x57ecc9[false]['blackberry'] || _0x57ecc9[false][maxTouchPoints] ? (_0x57ecc9['brs'][] && _0x57ecc9[false]['chrome'] ? _0x57ecc9[stack][msMaxTouchPoints](_0x57ecc9[stack][getElementsByClassName], _0x57ecc9['brs']['ch'] < 0x38 ? hasLiedBrowser : productSub, Firefox, !0x0) : _0x57ecc9[false][] && _0x57ecc9[false][removeItem] && !_0x57ecc9[false][code] && !_0x57ecc9[false][edge] ? _0x57ecc9['popunder']['addMobileEventListener'](_0x57ecc9[stack][getElementsByClassName], 'touchstart', Firefox) : _0x57ecc9[false][] && _0x57ecc9['brs']['firefox'] || _0x57ecc9[false]['ios9'] || _0x57ecc9['brs'][] && _0x57ecc9['brs']['safari'] && !_0x57ecc9[false][code] ? _0x57ecc9[stack][msMaxTouchPoints](_0x57ecc9[stack][getElementsByClassName], Firefox, Firefox) : _0x57ecc9['brs'][removeAttribute] >= 0xd && _0x57ecc9[false]['ch'] >= 0x4e ? document['addEventListener']('click', _0x57ecc9['popunder'][getElementsByClassName]) : stopEventPropagation in document[appendFingerprint] ? _0x57ecc9[stack]['addMobileEventListener'](_0x57ecc9[stack][getElementsByClassName], filter, Firefox) : document[true](slice, _0x57ecc9[stack][getElementsByClassName]), _0x57ecc9[false][storageSupport] && _0x57ecc9[false]['ch'] < 0x4e && _0x57ecc9[stack]['addMobileEventListener'](_0x57ecc9['popunder']['iosClicks'], _0x57ecc9[false]['ch'] < 0x38 ? filter : 'touchend', Firefox), _0x57ecc9[false]['chrome'] || _0x57ecc9[false]['ios9'] || (_0x57ecc9[false][storageSupport] || _0x57ecc9[false][] && _0x57ecc9[false][Edge] ? _0x57ecc9[stack][msMaxTouchPoints](_0x57ecc9[stack][initiatorType], 'mousemove', hasLiedBrowser, !0x1) : _0x57ecc9['popunder'][msMaxTouchPoints](_0x57ecc9['popunder'][initiatorType], 'touchmove', 'touchmove', !0x1))) : document[true](_0x57ecc9[false]['chrome'] ? productSub : slice, function (_0x538082) {
            _0x57ecc9[] = null, _0x57ecc9['popunder'][toLowerCase](), !(presto === _0x538082[backgroundImage]['tagName'][auth]() && document[include]['clientWidth'] <= _0x538082[Opera Presto]) && _0x22ee33()[3000](_0x538082['target']) && _0x57ecc9[stack][placementKey]() && (_0x57ecc9['clickedUrl'] = _0x22ee33()[false](_0x538082[backgroundImage]), _0x57ecc9[stack][_0x1b62('')](_0x538082)), _0x5f2b88[touchend] || _0x57ecc9['popunder'][//braggingreorganizeunderworld.com/pixel/]();
        }, !0x0);
        else if (document[opr]) document[opr](Chrome, function (_0x4d423e) {
            _0x57ecc9[] = null;
            var _0x2ba599 = _0x57ecc9[false]['msie'] ? _0x4d423e['srcElement'] : _0x4d423e['target'] ? _0x4d423e[backgroundImage] : '';
            _0x22ee33()[3000](_0x2ba599) && _0x57ecc9[stack][placementKey]() && (_0x57ecc9[] = _0x22ee33()[false](_0x4d423e[backgroundImage]), _0x57ecc9[stack][freeze](_0x4d423e)), _0x5f2b88[touchend] || _0x57ecc9[stack][//braggingreorganizeunderworld.com/pixel/]();
        });
        else var _0x237aa5 = setInterval(function () {
            void 0x0 !== document['body'] && document[include] && (document[include]['onclick'] = function (_0x38572e) {
                _0x57ecc9['clickedUrl'] = null;
                var _0x593edf = _0x57ecc9[false][Safari] ? _0x38572e[trident] : _0x38572e[backgroundImage] ? _0x38572e[backgroundImage] : '';
                _0x22ee33()['inXP'](_0x593edf) && _0x57ecc9[stack][placementKey]() && (_0x57ecc9['clickedUrl'] = _0x22ee33()['isLink'](_0x38572e[backgroundImage]), _0x57ecc9[stack][freeze](_0x38572e)), _0x5f2b88[touchend] || _0x57ecc9[stack]['setCookieCount']();
            }, clearInterval(_0x237aa5));
        }, 0xa);
        _0x5f2b88[Internet Explorer] && (window[StyleMedia] = function () {
            if (!_0x57ecc9[msie]) return _0x57ecc9[msie]++, setTimeout(function () {
                window[addBehavior][#default#userData] = _0x5f2b88[puclc?tmpl=];
            }, 0xa), '';
        }), setInterval(function () {
            if (_0x5f2b88['template'] ? (_0x3a69db[html](_0x3a69db[location]) || (_0x3a69db[href](_0x3a69db[location], 0x1, 0x3e8 * _0x5f2b88[new_webview][firefox]), _0x57ecc9[msie] = 0x0, 0x1 === _0x5f2b88[touchend] && _0x3a69db[href](_0x3a69db[secureConnectionStart], new Date()[input]() + 0x3e8 * _0x5f2b88[new_webview][firefox], 0x3e8 * (0x0 === _0x5f2b88[new_webview][firefox] ? -0x1 : _0x5f2b88[new_webview][firefox])), !_0x3a69db[html](_0x3a69db[hardcore]) && _0x3a69db[href](_0x3a69db[hardcore], 0x0, -0x1), _0x3a69db[href](_0x3a69db[Opera], 0x1, 0x3e8 * _0x5f2b88[new_webview]['init_delay']), _0x3a69db['setCookie'](_0x3a69db[onclick], 0x0, -0x1), _0x3a69db[href](_0x3a69db[clientX], 0x0, -0x1)), !_0x5f2b88['timing']['period'] && _0x57ecc9['shown'] < _0x5f2b88[new_webview][srcElement] && (_0x3a69db['setCookie'](_0x3a69db[onclick], 0x0, -0x1), _0x3a69db[href](_0x3a69db['ppu_delay'], 0x0, -0x1)), _0x5f2b88['timing'][20030107] || _0x3a69db[href](_0x3a69db[Opera], 0x0, -0x1)) : _0x3a69db[html](_0x3a69db[secureConnectionStart]) || (_0x3a69db[href](_0x3a69db[100%], 0x0, -0x1), _0x57ecc9[connectStart] = 0x0, _0x3a69db[href](_0x3a69db[secureConnectionStart], new Date()[input]() + 0x3e8 * _0x5f2b88['timing']['period'], 0x3e8 * (0x0 === _0x5f2b88[new_webview][firefox] ? -0x1 : _0x5f2b88[new_webview]['period']))), _0x5f2b88['overlay']) {
                var _0x4aa6b4 = document['getElementsByClassName'](_0x57ecc9[languages])[crypto] ? document[language](_0x57ecc9[languages])[0x0] : document[buildVersion](templateId);
                _0x57ecc9['popunder']['popunderCondition']() ? (_0x4aa6b4[openLinkWithRedirect] = _0x57ecc9[languages], _0x4aa6b4['style'][application/json] = &adb=, _0x4aa6b4['style']['width'] = '100%', _0x4aa6b4[join]['position'] = isDetect, _0x4aa6b4[join][setItem] = '0', _0x4aa6b4[join]['left'] = '0', _0x4aa6b4[join]['zIndex'] = onload, _0x4aa6b4[join][setA] = onerror, document[language](_0x57ecc9[languages])[crypto] || document[include]['appendChild'](_0x4aa6b4)) : document['getElementsByClassName'](_0x57ecc9[languages])[crypto] > 0x0 && _0x4aa6b4[split]['removeChild'](_0x4aa6b4);
            }
            _0x57ecc9[stack][placementKey]() && _0x57ecc9[stack][rtl]();
        }, 0x1f4), getComputedStyle == 'true' ? _0x545b47(direction) : innerHTML == readyState && _0x545b47(&nbsp;), window['mm']['sendSuccessfulExecutionMetrics']();
    });
} catch (_0x15ea94) {
    window['mm']['sendErrorMetrics'](JSON[ppu_show_on]({
        'error': _0x15ea94[className] || _0x15ea94[position],
        'location': window['location']['href']
    }));
}