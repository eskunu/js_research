< !doctype html > < html itemscope = ""
itemtype = "http://schema.org/WebPage"
lang = "en" > < head > < meta content = "Search the world's information, including webpages, images, videos and more. Google has many special features to help you find exactly what you're looking for."
name = "description" > < meta content = "noodp"
name = "robots" > < meta content = "text/html; charset=UTF-8"
http - equiv = "Content-Type" > < meta content = "/images/branding/googleg/1x/googleg_standard_color_128dp.png"
itemprop = "image" > < title > Google < /title><script nonce="lRbLF6B7lZu4JWSzjZ0/
1 A == ">(function(){window.google={kEI:'c9MJYYz2A6Cy5NoP54mxyAU',kEXPI:'0,772215,1,530320,56873,954,5104,207,4804,2316,383,246,5,1354,4936,314,6385,1116131,1197780,503,82,328902,51224,16114,28684,17572,4859,1361,9290,3027,17582,4020,978,13228,3847,4192,6434,1138,13386,235,4282,2777,919,5081,889,704,1279,2212,241,289,149,1103,840,1983,4314,109,3405,606,2023,2297,14670,3227,2845,7,12354,5096,7540,337,5036,1483,1924,908,2,940,15325,432,3,1590,1,5444,150,11322,2652,4,1528,2304,1236,5803,74,1983,2626,2015,4067,7434,3824,3050,2658,4243,3113,31,13628,2305,638,37,1457,5586,7266,2499,770,665,5809,2548,4094,20,3118,6,908,3,3541,1,5349,1,9360,1,1813,283,38,874,5998,12340,180,2,1394,738,18,769,8,1,1272,1715,2,3057,6155,627,4,32,4,5387,4,683,92,350,342,254,56,4,434,2379,121,1557,743,1275,1076,3502,1576,3,472,1818,5451,413,730,1160,1269,3425,3,1710,292,2381,2718,3709,2,835,3,125,5348,13,1447,87,3673,169,2850,1,8,176,2,2104,117,396,1999,1024,1510,107,231,87,555,51,811,358,158,190,565,4,321,93,836,626,383,1000,1578,206,2531,558,7,341,241,1063,1547,1161,685,326,1615,497,77,2,4,155,472,45,240,8,70,316,312,32,1091,1660,2,455,406,75,521,21,2982,5598297,2032,226,220,59,1,5995637,1171,151,2800546,882,444,1,2,80,1,1797,2,7,2,2551,1,748,141,795,563,1,4265,1,1,2,1331,3299,843,2609,155,17,13,72,139,4,2,20,2,169,13,19,46,5,39,96,548,29,2,2,1,2,1,2,2,7,4,1,2,2,2,2,2,2,353,513,186,1,1,158,3,2,2,2,2,2,4,2,3,3,235,34,10,72,11,23,2,2,13,13,28,4,23654680,299864,2773820,1265218,7,666,1641,338,3,1453,961,539,468,67,5,1710,251,7,772078',kBL:'mR2O'};google.sn='webhp';google.kHL='en';})();(function(){
var f = this || self;
var h, k = [];

function l(a) {
    for (var b; a && (!a.getAttribute || !(b = a.getAttribute("eid")));) a = a.parentNode;
    return b || h
}

function m(a) {
    for (var b = null; a && (!a.getAttribute || !(b = a.getAttribute("leid")));) a = a.parentNode;
    return b
}

function n(a, b, c, d, g) {
    var e = "";
    c || -1 !== b.search("&ei=") || (e = "&ei=" + l(d), -1 === b.search("&lei=") && (d = m(d)) && (e += "&lei=" + d));
    d = "";
    !c && f._cshid && -1 === b.search("&cshid=") && "slh" !== a && (d = "&cshid=" + f._cshid);
    c = c || "/" + (g || "gen_204") + "?atyp=i&ct=" + a + "&cad=" + b + e + "&zx=" + Date.now() + d;
    /^http:/i.test(c) && "https:" === window.location.protocol && (google.ml && google.ml(Error("a"), !1, {
        src: c,
        glmm: 1
    }), c = "");
    return c
};
h = google.kEI;
google.getEI = l;
google.getLEI = m;
google.ml = function () {
    return null
};
google.log = function (a, b, c, d, g) {
    if (c = n(a, b, c, d, g)) {
        a = new Image;
        var e = k.length;
        k[e] = a;
        a.onerror = a.onload = a.onabort = function () {
            delete k[e]
        };
        a.src = c
    }
};
google.logUrl = n;
}).call(this);
(function () {
    google.y = {};
    google.sy = [];
    google.x = function (a, b) {
        if (a) var c = a.id;
        else {
            do c = Math.random(); while (google.y[c])
        }
        google.y[c] = [a, b];
        return !1
    };
    google.sx = function (a) {
        google.sy.push(a)
    };
    google.lm = [];
    google.plm = function (a) {
        google.lm.push.apply(google.lm, a)
    };
    google.lq = [];
    google.load = function (a, b, c) {
        google.lq.push([
            [a], b, c
        ])
    };
    google.loadAll = function (a, b) {
        google.lq.push([a, b])
    };
    google.bx = !1;
    google.lx = function () {};
}).call(this);
google.f = {};
(function () {
    document.documentElement.addEventListener("submit", function (b) {
        var a;
        if (a = b.target) {
            var c = a.getAttribute("data-submitfalse");
            a = "1" == c || "q" == c && !a.elements.q.value ? !0 : !1
        } else a = !1;
        a && (b.preventDefault(), b.stopPropagation())
    }, !0);
    document.documentElement.addEventListener("click", function (b) {
        var a;
        a: {
            for (a = b.target; a && a != document.documentElement; a = a.parentElement)
                if ("A" == a.tagName) {
                    a = "1" == a.getAttribute("data-nohref");
                    break a
                } a = !1
        }
        a && b.preventDefault()
    }, !0);
}).call(this); < /script><style>#gb{font:13px/
27 px Arial, sans - serif;
height: 30 px
}#
gbz, #gbg {
    position: absolute;white - space: nowrap;top: 0;height: 30 px;z - index: 1000
}#
gbz {
    left: 0;padding - left: 4 px
}#
gbg {
    right: 0;padding - right: 5 px
}#
gbs {
    background: transparent;position: absolute;top: -999 px;visibility: hidden;z - index: 998;right: 0
}.gbto# gbs {
    background: #fff
}#
gbx3, #gbx4 {
    background - color: #2d2d2d;background-image:none;_background-image:none;background-position:0 -138px;background-repeat:repeat-x;border-bottom:1px solid # 000;
    font - size: 24 px;
    height: 29 px;
    _height: 30 px;
    opacity: 1;
    filter: alpha(opacity = 100);
    position: absolute;
    top: 0;
    width: 100 % ;
    z - index: 990
}#
gbx3 {
    left: 0
}#
gbx4 {
    right: 0
}#
gbb {
    position: relative
}#
gbbw {
    left: 0;position: absolute;top: 30 px;width: 100 %
}.gbtcb {
    position: absolute;visibility: hidden
}#
gbz.gbtcb {
    right: 0
}#
gbg.gbtcb {
    left: 0
}.gbxx {
    display: none!important
}.gbxo {
    opacity: 0!important;filter: alpha(opacity = 0) !important
}.gbm {
    position: absolute;z - index: 999;top: -999 px;visibility: hidden;text - align: left;border: 1 px solid# bebebe;background: #fff; - moz - box - shadow: -1 px 1 px 1 px rgba(0, 0, 0, .2); - webkit - box - shadow: 0 2 px 4 px rgba(0, 0, 0, .2);box - shadow: 0 2 px 4 px rgba(0, 0, 0, .2)
}.gbrtl.gbm {
    -moz - box - shadow: 1 px 1 px 1 px rgba(0, 0, 0, .2)
}.gbto.gbm, .gbto# gbs {
    top: 29 px;visibility: visible
}#
gbz.gbm {
    left: 0
}#
gbg.gbm {
    right: 0
}.gbxms {
    background - color: #ccc;
    display: block;
    position: absolute;
    z - index: 1;
    top: -1 px;
    left: -2 px;
    right: -2 px;
    bottom: -2 px;
    opacity: .4; - moz - border - radius: 3 px;
    filter: progid: DXImageTransform.Microsoft.Blur(pixelradius = 5);* opacity: 1;* top: -2 px;* left: -5 px;* right: 5 px;* bottom: 4 px; - ms - filter: "progid:DXImageTransform.Microsoft.Blur(pixelradius=5)";
    opacity: 1\ 0 / ;
    top: -4 px\ 0 / ;
    left: -6 px\ 0 / ;
    right: 5 px\ 0 / ;
    bottom: 4 px\ 0 /
}.gbma {
    position: relative;top: -1 px;border - style: solid dashed dashed;border - color: transparent;border - top - color: #c0c0c0;display: -moz - inline - box;display: inline - block;font - size: 0;height: 0;line - height: 0;width: 0;border - width: 3 px 3 px 0;padding - top: 1 px;left: 4 px
}#
gbztms1, #gbi4m1, #gbi4s, #gbi4t {
    zoom: 1
}.gbtc, .gbmc, .gbmcc {
    display: block;list - style: none;margin: 0;padding: 0
}.gbmc {
    background: #fff;padding: 10 px 0;position: relative;z - index: 2;zoom: 1
}.gbt {
    position: relative;display: -moz - inline - box;display: inline - block;line - height: 27 px;padding: 0;vertical - align: top
}.gbt {
    * display: inline
}.gbto {
    box - shadow: 0 2 px 4 px rgba(0, 0, 0, .2); - moz - box - shadow: 0 2 px 4 px rgba(0, 0, 0, .2); - webkit - box - shadow: 0 2 px 4 px rgba(0, 0, 0, .2)
}.gbzt, .gbgt {
    cursor: pointer;display: block;text - decoration: none!important
}
span# gbg6, span# gbg4 {
    cursor: default
}.gbts {
    border - left: 1 px solid transparent;
    border - right: 1 px solid transparent;
    display: block;* display: inline - block;
    padding: 0 5 px;
    position: relative;
    z - index: 1000
}.gbts {
    * display: inline
}.gbzt.gbts {
    display: inline;zoom: 1
}.gbto.gbts {
    background: #fff;border - color: #bebebe;color: #36c;padding-bottom:1px;padding-top:2px}.gbz0l .gbts{color:# fff;font - weight: bold
}.gbtsa {
    padding - right: 9 px
}#
gbz.gbzt, #gbz.gbgt, #gbg.gbgt {
    color: #ccc!important
}.gbtb2 {
    display: block;border - top: 2 px solid transparent
}.gbto.gbzt.gbtb2, .gbto.gbgt.gbtb2 {
    border - top - width: 0
}.gbtb.gbts {
    background: url(https: //ssl.gstatic.com/gb/images/b_8d5afc09.png);_background:url(https://ssl.gstatic.com/gb/images/b8_3615d64d.png);background-position:-27px -22px;border:0;font-size:0;padding:29px 0 0;*padding:27px 0 0;width:1px}.gbzt:hover,.gbzt:focus,.gbgt-hvr,.gbgt:focus{background-color:#4c4c4c;background-image:none;_background-image:none;background-position:0 -102px;background-repeat:repeat-x;outline:none;text-decoration:none !important}.gbpdjs .gbto .gbm{min-width:99%}.gbz0l .gbtb2{border-top-color:#dd4b39!important}#gbi4s,#gbi4s1{font-weight:bold}#gbg6.gbgt-hvr,#gbg6.gbgt:focus{background-color:transparent;background-image:none}.gbg4a{font-size:0;line-height:0}.gbg4a .gbts{padding:27px 5px 0;*padding:25px 5px 0}.gbto .gbg4a .gbts{padding:29px 5px 1px;*padding:27px 5px 1px}#gbi4i,#gbi4id{left:5px;border:0;height:24px;position:absolute;top:1px;width:24px}.gbto #gbi4i,.gbto #gbi4id{top:3px}.gbi4p{display:block;width:24px}#gbi4id{background-position:-44px -101px}#gbmpid{background-position:0 0}#gbmpi,#gbmpid{border:none;display:inline-block;height:48px;width:48px}#gbmpiw{display:inline-block;line-height:9px;padding-left:20px;margin-top:10px;position:relative}#gbmpi,#gbmpid,#gbmpiw{*display:inline}#gbg5{font-size:0}#gbgs5{padding:5px !important}.gbto #gbgs5{padding:7px 5px 6px !important}#gbi5{background:url(https://ssl.gstatic.com/gb/images/b_8d5afc09.png);_background:url(https://ssl.gstatic.com/gb/images/b8_3615d64d.png);background-position:0 0;display:block;font-size:0;height:17px;width:16px}.gbto #gbi5{background-position:-6px -22px}.gbn .gbmt,.gbn .gbmt:visited,.gbnd .gbmt,.gbnd .gbmt:visited{color:#dd8e27 !important}.gbf .gbmt,.gbf .gbmt:visited{color:#900 !important}.gbmt,.gbml1,.gbmlb,.gbmt:visited,.gbml1:visited,.gbmlb:visited{color:#36c !important;text-decoration:none !important}.gbmt,.gbmt:visited{display:block}.gbml1,.gbmlb,.gbml1:visited,.gbmlb:visited{display:inline-block;margin:0 10px}.gbml1,.gbmlb,.gbml1:visited,.gbmlb:visited{*display:inline}.gbml1,.gbml1:visited{padding:0 10px}.gbml1-hvr,.gbml1:focus{outline:none;text-decoration:underline !important}#gbpm .gbml1{display:inline;margin:0;padding:0;white-space:nowrap}.gbmlb,.gbmlb:visited{line-height:27px}.gbmlb-hvr,.gbmlb:focus{outline:none;text-decoration:underline !important}.gbmlbw{color:#ccc;margin:0 10px}.gbmt{padding:0 20px}.gbmt:hover,.gbmt:focus{background:#eee;cursor:pointer;outline:0 solid black;text-decoration:none !important}.gbm0l,.gbm0l:visited{color:#000 !important;font-weight:bold}.gbmh{border-top:1px solid #bebebe;font-size:0;margin:10px 0}#gbd4 .gbmc{background:#f5f5f5;padding-top:0}#gbd4 .gbsbic::-webkit-scrollbar-track:vertical{background-color:#f5f5f5;margin-top:2px}#gbmpdv{background:#fff;border-bottom:1px solid #bebebe;-moz-box-shadow:0 2px 4px rgba(0,0,0,.12);-o-box-shadow:0 2px 4px rgba(0,0,0,.12);-webkit-box-shadow:0 2px 4px rgba(0,0,0,.12);box-shadow:0 2px 4px rgba(0,0,0,.12);position:relative;z-index:1}#gbd4 .gbmh{margin:0}.gbmtc{padding:0;margin:0;line-height:27px}.GBMCC:last-child:after,#GBMPAL:last-child:after{content:'\0A\0A';white-space:pre;position:absolute}#gbmps{*zoom:1}#gbd4 .gbpc,#gbmpas .gbmt{line-height:17px}#gbd4 .gbpgs .gbmtc{line-height:27px}#gbd4 .gbmtc{border-bottom:1px solid #bebebe}#gbd4 .gbpc{display:inline-block;margin:16px 0 10px;padding-right:50px;vertical-align:top}#gbd4 .gbpc{*display:inline}.gbpc .gbps,.gbpc .gbps2{display:block;margin:0 20px}#gbmplp.gbps{margin:0 10px}.gbpc .gbps{color:#000;font-weight:bold}.gbpc .gbpd{margin-bottom:5px}.gbpd .gbmt,.gbpd .gbps{color:#666 !important}.gbpd .gbmt{opacity:.4;filter:alpha(opacity=40)}.gbps2{color:#666;display:block}.gbp0{display:none}.gbp0 .gbps2{font-weight:bold}#gbd4 .gbmcc{margin-top:5px}.gbpmc{background:#fef9db}.gbpmc .gbpmtc{padding:10px 20px}#gbpm{border:0;*border-collapse:collapse;border-spacing:0;margin:0;white-space:normal}#gbpm .gbpmtc{border-top:none;color:#000 !important;font:11px Arial,sans-serif}#gbpms{*white-space:nowrap}.gbpms2{font-weight:bold;white-space:nowrap}#gbmpal{*border-collapse:collapse;border-spacing:0;border:0;margin:0;white-space:nowrap;width:100%}.gbmpala,.gbmpalb{font:13px Arial,sans-serif;line-height:27px;padding:10px 20px 0;white-space:nowrap}.gbmpala{padding-left:0;text-align:left}.gbmpalb{padding-right:0;text-align:right}#gbmpasb .gbps{color:#000}#gbmpal .gbqfbb{margin:0 20px}.gbp0 .gbps{*display:inline}a.gbiba{margin:8px 20px 10px}.gbmpiaw{display:inline-block;padding-right:10px;margin-bottom:6px;margin-top:10px}.gbxv{visibility:hidden}.gbmpiaa{display:block;margin-top:10px}.gbmpia{border:none;display:block;height:48px;width:48px}.gbmpnw{display:inline-block;height:auto;margin:10px 0;vertical-align:top}
        .gbqfb, .gbqfba, .gbqfbb {
            -moz - border - radius: 2 px; - webkit - border - radius: 2 px;
            border - radius: 2 px;
            cursor: default !important;
            display: inline - block;
            font - weight: bold;
            height: 29 px;
            line - height: 29 px;
            min - width: 54 px;* min - width: 70 px;
            padding: 0 8 px;
            text - align: center;
            text - decoration: none!important; - moz - user - select: none; - webkit - user - select: none
        }.gbqfb: focus, .gbqfba: focus, .gbqfbb: focus {
            border: 1 px solid #4d90fe;-moz-box-shadow:inset 0 0 0 1px rgba(255, 255, 255, 0.5);-webkit-box-shadow:inset 0 0 0 1px rgba(255, 255, 255, 0.5);box-shadow:inset 0 0 0 1px rgba(255, 255, 255, 0.5);outline:none}.gbqfb-hvr:focus,.gbqfba-hvr:focus,.gbqfbb-hvr:focus{-webkit-box-shadow:inset 0 0 0 1px # fff,
            0 1 px 1 px rgba(0, 0, 0, .1); - moz - box - shadow: inset 0 0 0 1 px# fff,
            0 1 px 1 px rgba(0, 0, 0, .1);box - shadow: inset 0 0 0 1 px# fff,
            0 1 px 1 px rgba(0, 0, 0, .1)
        }.gbqfb - no - focus: focus {
            border: 1 px solid #3079ed;-moz-box-shadow:none;-webkit-box-shadow:none;box-shadow:none}.gbqfb-hvr,.gbqfba-hvr,.gbqfbb-hvr{-webkit-box-shadow:0 1px 1px rgba(0,0,0,.1);-moz-box-shadow:0 1px 1px rgba(0,0,0,.1);box-shadow:0 1px 1px rgba(0,0,0,.1)}.gbqfb::-moz-focus-inner,.gbqfba::-moz-focus-inner,.gbqfbb::-moz-focus-inner{border:0}.gbqfba,.gbqfbb{border:1px solid # dcdcdc;border - color: rgba(0, 0, 0, .1);color: #444 !important;font-size:11px}.gbqfb{background-color:# 4 d90fe;background - image: -webkit - gradient(linear, left top, left bottom, from(#4d90fe),to(# 4787 ed));background - image: -webkit - linear - gradient(top, #4d90fe,# 4787 ed);background - image: -moz - linear - gradient(top, #4d90fe,# 4787 ed);background - image: -ms - linear - gradient(top, #4d90fe,# 4787 ed);background - image: -o - linear - gradient(top, #4d90fe,# 4787 ed);background - image: linear - gradient(top, #4d90fe,# 4787 ed);filter: progid: DXImageTransform.Microsoft.gradient(startColorStr = '#4d90fe', EndColorStr = '#4787ed');border: 1 px solid #3079ed;color:# fff!important;margin: 0 0
        }.gbqfb - hvr {
            border - color: #2f5bb7}.gbqfb-hvr:focus{border-color:# 2 f5bb7
        }.gbqfb - hvr, .gbqfb - hvr: focus {
            background - color: #357ae8;background-image:-webkit-gradient(linear,left top,left bottom,from(# 4 d90fe), to(#357ae8));background-image:-webkit-linear-gradient(top,# 4 d90fe, #357ae8);background-image:-moz-linear-gradient(top,# 4 d90fe, #357ae8);background-image:-ms-linear-gradient(top,# 4 d90fe, #357ae8);background-image:-o-linear-gradient(top,# 4 d90fe, #357ae8);background-image:linear-gradient(top,# 4 d90fe, #357ae8)}.gbqfb:active{background-color:inherit;-webkit-box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.3);box-shadow:inset 0 1px 2px rgba(0, 0, 0, 0.3)}.gbqfba{background-color:# f5f5f5; background - image: -webkit - gradient(linear, left top, left bottom, from(#f5f5f5), to(#f1f1f1)); background - image: -webkit - linear - gradient(top, #f5f5f5, #f1f1f1); background - image: -moz - linear - gradient(top, #f5f5f5, #f1f1f1); background - image: -ms - linear - gradient(top, #f5f5f5, #f1f1f1); background - image: -o - linear - gradient(top, #f5f5f5, #f1f1f1); background - image: linear - gradient(top, #f5f5f5, #f1f1f1); filter: progid: DXImageTransform.Microsoft.gradient(startColorStr = '#f5f5f5', EndColorStr = '#f1f1f1')
        }.gbqfba - hvr, .gbqfba - hvr: active {
            background - color: #f8f8f8;
            background - image: -webkit - gradient(linear, left top, left bottom, from(#f8f8f8), to(#f1f1f1));
            background - image: -webkit - linear - gradient(top, #f8f8f8, #f1f1f1);
            background - image: -moz - linear - gradient(top, #f8f8f8, #f1f1f1);
            background - image: -ms - linear - gradient(top, #f8f8f8, #f1f1f1);
            background - image: -o - linear - gradient(top, #f8f8f8, #f1f1f1);
            background - image: linear - gradient(top, #f8f8f8, #f1f1f1);
            filter: progid: DXImageTransform.Microsoft.gradient(startColorStr = '#f8f8f8', EndColorStr = '#f1f1f1')
        }.gbqfbb {
            background - color: #fff;
            background - image: -webkit - gradient(linear, left top, left bottom, from(#fff), to(#fbfbfb));
            background - image: -webkit - linear - gradient(top, #fff, #fbfbfb);
            background - image: -moz - linear - gradient(top, #fff, #fbfbfb);
            background - image: -ms - linear - gradient(top, #fff, #fbfbfb);
            background - image: -o - linear - gradient(top, #fff, #fbfbfb);
            background - image: linear - gradient(top, #fff, #fbfbfb);
            filter: progid: DXImageTransform.Microsoft.gradient(startColorStr = '#ffffff', EndColorStr = '#fbfbfb')
        }.gbqfbb - hvr, .gbqfbb - hvr: active {
            background - color: #fff;
            background - image: -webkit - gradient(linear, left top, left bottom, from(#fff), to(#f8f8f8));
            background - image: -webkit - linear - gradient(top, #fff, #f8f8f8);
            background - image: -moz - linear - gradient(top, #fff, #f8f8f8);
            background - image: -ms - linear - gradient(top, #fff, #f8f8f8);
            background - image: -o - linear - gradient(top, #fff, #f8f8f8);
            background - image: linear - gradient(top, #fff, #f8f8f8);
            filter: progid: DXImageTransform.Microsoft.gradient(startColorStr = '#ffffff', EndColorStr = '#f8f8f8')
        }.gbqfba - hvr, .gbqfba - hvr: active, .gbqfbb - hvr, .gbqfbb - hvr: active {
            border - color: #c6c6c6; - webkit - box - shadow: 0 1 px 1 px rgba(0, 0, 0, .1); - moz - box - shadow: 0 1 px 1 px rgba(0, 0, 0, .1);
            box - shadow: 0 1 px 1 px rgba(0, 0, 0, .1);
            color: #222 !important}.gbqfba:active,.gbqfbb:active{-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1)}

# gbmpas {
                max - height: 220 px
            }#
            gbmm {
                max - height: 530 px
            }.gbsb {
                -webkit - box - sizing: border - box;
                display: block;
                position: relative;* zoom: 1
            }.gbsbic {
                overflow: auto
            }.gbsbis.gbsbt, .gbsbis.gbsbb {
                    -webkit - mask - box - image: -webkit - gradient(linear, left top, right top, color - stop(0, rgba(0, 0, 0, .1)), color - stop(.5, rgba(0, 0, 0, .8)), color - stop(1, rgba(0, 0, 0, .1)));
                    left: 0;
                    margin - right: 0;
                    opacity: 0;
                    position: absolute;
                    width: 100 %
                }.gbsb.gbsbt: after, .gbsb.gbsbb: after {
                    content: "";display: block;height: 0;left: 0;position: absolute;width: 100 %
                }.gbsbis.gbsbt {
                    background: -webkit - gradient(linear, left top, left bottom, from(rgba(0, 0, 0, .2)), to(rgba(0, 0, 0, 0)));background - image: -webkit - linear - gradient(top, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));background - image: -moz - linear - gradient(top, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));background - image: -ms - linear - gradient(top, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));background - image: -o - linear - gradient(top, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));background - image: linear - gradient(top, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));height: 6 px;top: 0
                }.gbsb.gbsbt: after {
                    border - top: 1 px solid# ebebeb;
                    border - color: rgba(0, 0, 0, .3);
                    top: 0
                }.gbsb.gbsbb {
                    -webkit - mask - box - image: -webkit - gradient(linear, left top, right top, color - stop(0, rgba(0, 0, 0, .1)), color - stop(.5, rgba(0, 0, 0, .8)), color - stop(1, rgba(0, 0, 0, .1)));
                    background: -webkit - gradient(linear, left bottom, left top, from(rgba(0, 0, 0, .2)), to(rgba(0, 0, 0, 0)));
                    background - image: -webkit - linear - gradient(bottom, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));
                    background - image: -moz - linear - gradient(bottom, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));
                    background - image: -ms - linear - gradient(bottom, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));
                    background - image: -o - linear - gradient(bottom, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));
                    background - image: linear - gradient(bottom, rgba(0, 0, 0, .2), rgba(0, 0, 0, 0));
                    bottom: 0;
                    height: 4 px
                }.gbsb.gbsbb: after {
                    border - bottom: 1 px solid# ebebeb;
                    border - color: rgba(0, 0, 0, .3);
                    bottom: 0
                } <
                /style><style>body,td,a,p,.h{font-family:arial,sans-serif}body{margin:0;overflow-y:scroll}#gog{padding:3px 8px 0}td{line-height:.8em}.gac_m td{line-height:17px}form{margin-bottom:20px}.h{color:#1558d6}em{font-weight:bold;font-style:normal}.lst{height:25px;width:496px}.gsfi,.lst{font:18px arial,sans-serif}.gsfs{font:17px arial,sans-serif}.ds{display:inline-box;display:inline-block;margin:3px 0 4px;margin-left:4px}input{font-family:inherit}body{background:#fff;color:#000}a{color:#4b11a8;text-decoration:none}a:hover,a:active{text-decoration:underline}.fl a{color:#1558d6}a:visited{color:#4b11a8}.sblc{padding-top:5px}.sblc a{display:block;margin:2px 0;margin-left:13px;font-size:11px}.lsbb{background:#f8f9fa;border:solid 1px;border-color:#dadce0 #70757a #70757a #dadce0;height:30px}.lsbb{display:block}#WqQANb a{display:inline-block;margin:0 12px}.lsb{background:url(/images / nav_logo229.png) 0 - 261 px repeat - x; border: none; color: #000;cursor:pointer;height:30px;margin:0;outline:0;font:15px arial,sans-serif;vertical-align:top}.lsb:active{background:# dadce0
    }.lst: focus {
        outline: none
    } < /style><script nonce="lRbLF6B7lZu4JWSzjZ0/
    1 A == ">(function(){try{/*

    Copyright The Closure Library Authors.
    SPDX - License - Identifier: Apache - 2.0 *
        /
    var e = this || self;
    var aa = function (a, b, c, d) {
        d = d || {};
        d._sn = ["cfg", b, c].join(".");
        window.gbar.logger.ml(a, d)
    };
    var g = window.gbar = window.gbar || {},
        h = window.gbar.i = window.gbar.i || {},
        ba;

    function _tvn(a, b) {
        a = parseInt(a, 10);
        return isNaN(a) ? b : a
    }

    function _tvf(a, b) {
        a = parseFloat(a);
        return isNaN(a) ? b : a
    }

    function _tvv(a) {
        return !!a
    }

    function p(a, b, c) {
        (c || g)[a] = b
    }
    g.bv = {
        n: _tvn("2", 0),
        r: "",
        f: ".66.41.",
        e: "1300102,3700328,3700831,3700913",
        m: _tvn("1", 1)
    };

    function ca(a, b, c) {
        var d = "on" + b;
        if (a.addEventListener) a.addEventListener(b, c, !1);
        else if (a.attachEvent) a.attachEvent(d, c);
        else {
            var f = a[d];
            a[d] = function () {
                var k = f.apply(this, arguments),
                    m = c.apply(this, arguments);
                return void 0 == k ? m : void 0 == m ? k : m && k
            }
        }
    }
    var da = function (a) {
            return function () {
                return g.bv.m == a
            }
        },
        ea = da(1),
        fa = da(2);p("sb", ea);p("kn", fa);h.a = _tvv;h.b = _tvf;h.c = _tvn;h.i = aa;
    var r = window.gbar.i.i;
    var t = function () {},
        ha = function () {},
        ka = function (a) {
            var b = new Image,
                c = ia;
            b.onerror = b.onload = b.onabort = function () {
                try {
                    delete ja[c]
                } catch (d) {}
            };
            ja[c] = b;
            b.src = a;
            ia = c + 1
        },
        ja = [],
        ia = 0;p("logger", {
        il: ha,
        ml: t,
        log: ka
    });
    var u = window.gbar.logger;
    var v = {},
        la = {},
        w = [],
        ma = h.b("0.1", .1),
        na = h.a("1", !0),
        oa = function (a, b) {
            w.push([a, b])
        },
        pa = function (a, b) {
            v[a] = b
        },
        qa = function (a) {
            return a in v
        },
        x = {},
        A = function (a, b) {
            x[a] || (x[a] = []);
            x[a].push(b)
        },
        B = function (a) {
            A("m", a)
        },
        ra = function (a, b) {
            var c = document.createElement("script");
            c.src = a;
            c.async = na;
            Math.random() < ma && (c.onerror = function () {
                c.onerror = null;
                t(Error("Bundle load failed: name=" + (b || "UNK") + " url=" + a))
            });
            (document.getElementById("xjsc") || document.getElementsByTagName("body")[0] ||
                document.getElementsByTagName("head")[0]).appendChild(c)
        },
        D = function (a) {
            for (var b = 0, c;
                (c = w[b]) && c[0] != a; ++b);
            !c || c[1].l || c[1].s || (c[1].s = !0, sa(2, a), c[1].url && ra(c[1].url, a), c[1].libs && C && C(c[1].libs))
        },
        ta = function (a) {
            A("gc", a)
        },
        ua = null,
        va = function (a) {
            ua = a
        },
        sa = function (a, b, c) {
            if (ua) {
                a = {
                    t: a,
                    b: b
                };
                if (c)
                    for (var d in c) a[d] = c[d];
                try {
                    ua(a)
                } catch (f) {}
            }
        };p("mdc", v);p("mdi", la);p("bnc", w);p("qGC", ta);p("qm", B);p("qd", x);p("lb", D);p("mcf", pa);p("bcf", oa);p("aq", A);p("mdd", "");
    p("has", qa);p("trh", va);p("tev", sa);
    if (h.a("m;/_/scs/abc-static/_/js/k=gapi.gapi.en.2cdKFnNWjuc.O/d=1/rs=AHpOoo-rZMnae0kdWLu9CWmKEzOTJj_h7w/m=__features__")) {
        var F = function (a, b) {
                return wa ? a || b : b
            },
            xa = h.a("1"),
            ya = h.a(""),
            za = h.a(""),
            wa = h.a(""),
            Aa = window.gapi = F(window.gapi, {}),
            Ba = function (a, b) {
                var c = function () {
                    g.dgl(a, b)
                };
                xa ? B(c) : (A("gl", c), D("gl"))
            },
            Ca = {},
            Da = function (a) {
                a = a.split(":");
                for (var b;
                    (b = a.pop()) && Ca[b];);
                return !b
            },
            C = function (a) {
                function b() {
                    for (var c = a.split(":"), d = 0, f; f = c[d]; ++d) Ca[f] = 1;
                    for (c = 0; d = w[c]; ++c) d = d[1], (f = d.libs) && !d.l && d.i &&
                        Da(f) && d.i()
                }
                g.dgl(a, b)
            },
            G = window.___jsl = F(window.___jsl, {});
        G.h = F(G.h, "m;/_/scs/abc-static/_/js/k=gapi.gapi.en.2cdKFnNWjuc.O/d=1/rs=AHpOoo-rZMnae0kdWLu9CWmKEzOTJj_h7w/m=__features__");
        G.ms = F(G.ms, "https://apis.google.com");
        G.m = F(G.m, "");
        G.l = F(G.l, []);
        G.dpo = F(G.dpo, "");
        xa || w.push(["gl", {
            url: "//ssl.gstatic.com/gb/js/abc/glm_e7bb39a7e1a24581ff4f8d199678b1b9.js"
        }]);
        var Ea = {
            pu: ya,
            sh: "",
            si: za,
            hl: "en"
        };
        v.gl = Ea;
        wa ? Aa.load || p("load", Ba, Aa) : p("load", Ba, Aa);
        p("dgl", Ba);
        p("agl", Da);
        h.o = xa
    };
    var Fa = h.b("0.1", .001),
        Ga = 0;

    function _mlToken(a, b) {
        try {
            if (1 > Ga) {
                Ga++;
                var c = a;
                b = b || {};
                var d = encodeURIComponent,
                    f = ["//www.google.com/gen_204?atyp=i&zx=", (new Date).getTime(), "&jexpid=", d("28834"), "&srcpg=", d("prop=1"), "&jsr=", Math.round(1 / Fa), "&ogev=", d("c9MJYduFBYfAytMPqsS3iAQ"), "&ogf=", g.bv.f, "&ogrp=", d(""), "&ogv=", d("386777444.0"), "&oggv=" + d("es_plusone_gc_20210707.0_p0"), "&ogd=", d("com"), "&ogc=", d("USA"), "&ogl=", d("en")];
                b._sn && (b._sn =
                    "og." + b._sn);
                for (var k in b) f.push("&"), f.push(d(k)), f.push("="), f.push(d(b[k]));
                f.push("&emsg=");
                f.push(d(c.name + ":" + c.message));
                var m = f.join("");
                Ha(m) && (m = m.substr(0, 2E3));
                var n = m;
                var l = window.gbar.logger._aem(a, n);
                ka(l)
            }
        } catch (q) {}
    }
    var Ha = function (a) {
            return 2E3 <= a.length
        },
        Ia = function (a, b) {
            return b
        };

    function Ja(a) {
        t = a;
        p("_itl", Ha, u);
        p("_aem", Ia, u);
        p("ml", t, u);
        a = {};
        v.er = a
    }
    h.a("") ? Ja(function (a) {
        throw a;
    }) : h.a("1") && Math.random() < Fa && Ja(_mlToken);
    var _E = "left",
        Ka = h.a(""),
        J = function (a, b) {
            var c = a.className;
            H(a, b) || (a.className += ("" != c ? " " : "") + b)
        },
        K = function (a, b) {
            var c = a.className;
            b = new RegExp("\\s?\\b" + b + "\\b");
            c && c.match(b) && (a.className = c.replace(b, ""))
        },
        H = function (a, b) {
            b = new RegExp("\\b" + b + "\\b");
            a = a.className;
            return !(!a || !a.match(b))
        },
        La = function (a, b) {
            H(a, b) ? K(a, b) : J(a, b)
        },
        Ma = function (a, b) {
            a[b] = function (c) {
                var d = arguments;
                g.qm(function () {
                    a[b].apply(this, d)
                })
            }
        },
        Na = function (a) {
            a = ["//www.gstatic.com", "/og/_/js/d=1/k=",
                "og.og2.en_US.eHDH2IbUSLo.O", "/rt=j/m=", a, "/rs=", "AA2YrTsQHC9m1ytmPZmoPzV_JFKKhNZ9YA"
            ];
            Ka && a.push("?host=www.gstatic.com&bust=og.og2.en_US.yvmj3W4izSo.DU");
            a = a.join("");
            ra(a)
        };p("ca", J);p("cr", K);p("cc", H);h.k = J;h.l = K;h.m = H;h.n = La;h.p = Na;h.q = Ma;
    var Oa = ["gb_71", "gb_155"],
        Pa;

    function Qa(a) {
        Pa = a
    }

    function Ra(a) {
        var b = Pa && !a.href.match(/.*\/accounts\/ClearSID[?]/) && encodeURIComponent(Pa());
        b && (a.href = a.href.replace(/([?&]continue=)[^&]*/, "$1" + b))
    }

    function Sa(a) {
        window.gApplication && (a.href = window.gApplication.getTabUrl(a.href))
    }

    function Ta(a) {
        try {
            var b = (document.forms[0].q || "").value;
            b && (a.href = a.href.replace(/([?&])q=[^&]*|$/, function (c, d) {
                return (d || "&") + "q=" + encodeURIComponent(b)
            }))
        } catch (c) {
            r(c, "sb", "pq")
        }
    }
    var Ua = function () {
            for (var a = [], b = 0, c; c = Oa[b]; ++b)(c = document.getElementById(c)) && a.push(c);
            return a
        },
        Va = function () {
            var a = Ua();
            return 0 < a.length ? a[0] : null
        },
        Wa = function () {
            return document.getElementById("gb_70")
        },
        L = {},
        M = {},
        Xa = {},
        N = {},
        O = void 0,
        bb = function (a, b) {
            try {
                var c = document.getElementById("gb");
                J(c, "gbpdjs");
                P();
                Ya(document.getElementById("gb")) && J(c, "gbrtl");
                if (b && b.getAttribute) {
                    var d = b.getAttribute("aria-owns");
                    if (d.length) {
                        var f = document.getElementById(d);
                        if (f) {
                            var k = b.parentNode;
                            if (O == d) O = void 0,
                                K(k, "gbto");
                            else {
                                if (O) {
                                    var m = document.getElementById(O);
                                    if (m && m.getAttribute) {
                                        var n = m.getAttribute("aria-owner");
                                        if (n.length) {
                                            var l = document.getElementById(n);
                                            l && l.parentNode && K(l.parentNode, "gbto")
                                        }
                                    }
                                }
                                Za(f) && $a(f);
                                O = d;
                                J(k, "gbto")
                            }
                        }
                    }
                }
                B(function () {
                    g.tg(a, b, !0)
                });
                ab(a)
            } catch (q) {
                r(q, "sb", "tg")
            }
        },
        cb = function (a) {
            B(function () {
                g.close(a)
            })
        },
        db = function (a) {
            B(function () {
                g.rdd(a)
            })
        },
        Ya = function (a) {
            var b, c = document.defaultView;
            c && c.getComputedStyle ? (a = c.getComputedStyle(a, "")) && (b = a.direction) : b = a.currentStyle ?
                a.currentStyle.direction : a.style.direction;
            return "rtl" == b
        },
        fb = function (a, b, c) {
            if (a) try {
                var d = document.getElementById("gbd5");
                if (d) {
                    var f = d.firstChild,
                        k = f.firstChild,
                        m = document.createElement("li");
                    m.className = b + " gbmtc";
                    m.id = c;
                    a.className = "gbmt";
                    m.appendChild(a);
                    if (k.hasChildNodes()) {
                        c = [
                            ["gbkc"],
                            ["gbf", "gbe", "gbn"],
                            ["gbkp"],
                            ["gbnd"]
                        ];
                        d = 0;
                        var n = k.childNodes.length;
                        f = !1;
                        for (var l = -1, q = 0, E; E = c[q]; q++) {
                            for (var U = 0, I; I = E[U]; U++) {
                                for (; d < n && H(k.childNodes[d], I);) d++;
                                if (I == b) {
                                    k.insertBefore(m, k.childNodes[d] ||
                                        null);
                                    f = !0;
                                    break
                                }
                            }
                            if (f) {
                                if (d + 1 < k.childNodes.length) {
                                    var V = k.childNodes[d + 1];
                                    H(V.firstChild, "gbmh") || eb(V, E) || (l = d + 1)
                                } else if (0 <= d - 1) {
                                    var W = k.childNodes[d - 1];
                                    H(W.firstChild, "gbmh") || eb(W, E) || (l = d)
                                }
                                break
                            }
                            0 < d && d + 1 < n && d++
                        }
                        if (0 <= l) {
                            var y = document.createElement("li"),
                                z = document.createElement("div");
                            y.className = "gbmtc";
                            z.className = "gbmt gbmh";
                            y.appendChild(z);
                            k.insertBefore(y, k.childNodes[l])
                        }
                        g.addHover && g.addHover(a)
                    } else k.appendChild(m)
                }
            } catch (Db) {
                r(Db, "sb", "al")
            }
        },
        eb = function (a, b) {
            for (var c = b.length,
                    d = 0; d < c; d++)
                if (H(a, b[d])) return !0;
            return !1
        },
        gb = function (a, b, c) {
            fb(a, b, c)
        },
        hb = function (a, b) {
            fb(a, "gbe", b)
        },
        ib = function () {
            B(function () {
                g.pcm && g.pcm()
            })
        },
        jb = function () {
            B(function () {
                g.pca && g.pca()
            })
        },
        kb = function (a, b, c, d, f, k, m, n, l, q) {
            B(function () {
                g.paa && g.paa(a, b, c, d, f, k, m, n, l, q)
            })
        },
        lb = function (a, b) {
            L[a] || (L[a] = []);
            L[a].push(b)
        },
        mb = function (a, b) {
            M[a] || (M[a] = []);
            M[a].push(b)
        },
        nb = function (a, b) {
            Xa[a] = b
        },
        ob = function (a, b) {
            N[a] || (N[a] = []);
            N[a].push(b)
        },
        ab = function (a) {
            a.preventDefault && a.preventDefault();
            a.returnValue = !1;
            a.cancelBubble = !0
        },
        pb = null,
        $a = function (a, b) {
            P();
            if (a) {
                qb(a, "Opening&hellip;");
                Q(a, !0);
                b = "undefined" != typeof b ? b : 1E4;
                var c = function () {
                    rb(a)
                };
                pb = window.setTimeout(c, b)
            }
        },
        sb = function (a) {
            P();
            a && (Q(a, !1), qb(a, ""))
        },
        rb = function (a) {
            try {
                P();
                var b = a || document.getElementById(O);
                b && (qb(b, "This service is currently unavailable.%1$sPlease try again later.", "%1$s"), Q(b, !0))
            } catch (c) {
                r(c, "sb", "sdhe")
            }
        },
        qb = function (a, b, c) {
            if (a && b) {
                var d = Za(a);
                if (d) {
                    if (c) {
                        d.textContent = "";
                        b = b.split(c);
                        c = 0;
                        for (var f; f = b[c]; c++) {
                            var k = document.createElement("div");
                            k.innerHTML = f;
                            d.appendChild(k)
                        }
                    } else d.innerHTML = b;
                    Q(a, !0)
                }
            }
        },
        Q = function (a, b) {
            (b = void 0 !== b ? b : !0) ? J(a, "gbmsgo"): K(a, "gbmsgo")
        },
        Za = function (a) {
            for (var b = 0, c; c = a.childNodes[b]; b++)
                if (H(c, "gbmsg")) return c
        },
        P = function () {
            pb && window.clearTimeout(pb)
        },
        tb = function (a) {
            var b = "inner" + a;
            a = "offset" + a;
            return window[b] ? window[b] : document.documentElement && document.documentElement[a] ? document.documentElement[a] : 0
        },
        ub = function () {
            return !1
        },
        vb = function () {
            return !!O
        };p("so", Va);p("sos", Ua);p("si", Wa);p("tg", bb);
    p("close", cb);p("rdd", db);p("addLink", gb);p("addExtraLink", hb);p("pcm", ib);p("pca", jb);p("paa", kb);p("ddld", $a);p("ddrd", sb);p("dderr", rb);p("rtl", Ya);p("op", vb);p("bh", L);p("abh", lb);p("dh", M);p("adh", mb);p("ch", N);p("ach", ob);p("eh", Xa);p("aeh", nb);ba = h.a("") ? Sa : Ta;p("qs", ba);p("setContinueCb", Qa);p("pc", Ra);p("bsy", ub);h.d = ab;h.j = tb;
    var wb = {};v.base = wb;w.push(["m", {
        url: "//ssl.gstatic.com/gb/js/sem_12e7ff88a8fc6c909834b2d156d35204.js"
    }]);g.sg = {
        c: "1"
    };p("wg", {
        rg: {}
    });
    var xb = {
        tiw: h.c("15000", 0),
        tie: h.c("30000", 0)
    };v.wg = xb;
    var yb = {
        thi: h.c("10000", 0),
        thp: h.c("180000", 0),
        tho: h.c("5000", 0),
        tet: h.b("0.5", 0)
    };v.wm = yb;
    if (h.a("1")) {
        var zb = h.a("");
        w.push(["gc", {
            auto: zb,
            url: "//ssl.gstatic.com/gb/js/abc/gci_91f30755d6a6b787dcc2a4062e6e9824.js",
            libs: "googleapis.client:gapi.iframes"
        }]);
        var Ab = {
            version: "gci_91f30755d6a6b787dcc2a4062e6e9824.js",
            index: "",
            lang: "en"
        };
        v.gc = Ab;
        var Bb = function (a) {
            window.googleapis && window.iframes ? a && a() : (a && ta(a), D("gc"))
        };
        p("lGC", Bb);
        h.a("1") && p("lPWF", Bb)
    };window.__PVT = "";
    if (h.a("1") && h.a("1")) {
        var Cb = function (a) {
            Bb(function () {
                A("pw", a);
                D("pw")
            })
        };
        p("lPW", Cb);
        w.push(["pw", {
            url: "//ssl.gstatic.com/gb/js/abc/pwm_45f73e4df07a0e388b0fa1f3d30e7280.js"
        }]);
        var Eb = [],
            Fb = function (a) {
                Eb[0] = a
            },
            Gb = function (a, b) {
                b = b || {};
                b._sn = "pw";
                t(a, b)
            },
            Hb = {
                signed: Eb,
                elog: Gb,
                base: "https://plusone.google.com/u/0",
                loadTime: (new Date).getTime()
            };
        v.pw = Hb;
        var Ib = function (a, b) {
            var c = b.split(".");
            b = function () {
                var m = arguments;
                a(function () {
                    for (var n = g, l = 0, q = c.length - 1; l < q; ++l) n = n[c[l]];
                    n[c[l]].apply(n, m)
                })
            };
            for (var d = g, f = 0, k = c.length - 1; f <
                k; ++f) d = d[c[f]] = d[c[f]] || {};
            return d[c[f]] = b
        };
        Ib(Cb, "pw.clk");
        Ib(Cb, "pw.hvr");
        p("su", Fb, g.pw)
    };
    var Jb = [1, 2, 3, 4, 5, 6, 9, 10, 11, 13, 14, 28, 29, 30, 34, 35, 37, 38, 39, 40, 41, 42, 43, 48, 49, 500];
    var Kb = h.b("0.001", 1E-4),
        Lb = h.b("1", 1),
        Mb = !1,
        Nb = !1;
    if (h.a("1")) {
        var Ob = Math.random();
        Ob < Kb && (Mb = !0);
        Ob < Lb && (Nb = !0)
    }
    var R = null;

    function Pb(a, b) {
        var c = Kb,
            d = Mb;
        var f = a;
        if (!R) {
            R = {};
            for (var k = 0; k < Jb.length; k++) {
                var m = Jb[k];
                R[m] = !0
            }
        }
        if (f = !!R[f]) c = Lb, d = Nb;
        if (d) {
            d = encodeURIComponent;
            if (g.rp) {
                var n = g.rp();
                n = "-1" != n ? n : ""
            } else n = "";
            f = (new Date).getTime();
            k = d("28834");
            m = d("c9MJYduFBYfAytMPqsS3iAQ");
            var l = g.bv.f,
                q = d("1");
            n = d(n);
            c = Math.round(1 / c);
            var E = d("386777444.0"),
                U = "&oggv=" + d("es_plusone_gc_20210707.0_p0"),
                I = d("com"),
                V = d("en"),
                W =
                d("USA");
            var y = 0;
            h.a("") && (y |= 1);
            h.a("") && (y |= 2);
            h.a("") && (y |= 4);
            a = ["//www.google.com/gen_204?atyp=i&zx=", f, "&oge=", a, "&ogex=", k, "&ogev=", m, "&ogf=", l, "&ogp=", q, "&ogrp=", n, "&ogsr=", c, "&ogv=", E, U, "&ogd=", I, "&ogl=", V, "&ogc=", W, "&ogus=", y];
            if (b) {
                "ogw" in b && (a.push("&ogw=" + b.ogw), delete b.ogw);
                f = [];
                for (z in b) 0 != f.length && f.push(","), f.push(Qb(z)), f.push("."), f.push(Qb(b[z]));
                var z = f.join("");
                "" != z && (a.push("&ogad="), a.push(d(z)))
            }
            ka(a.join(""))
        }
    }

    function Qb(a) {
        "number" == typeof a && (a += "");
        return "string" == typeof a ? a.replace(".", "%2E").replace(",", "%2C") : a
    }
    ha = Pb;p("il", ha, u);
    var Rb = {};v.il = Rb;
    var Sb = function (a, b, c, d, f, k, m, n, l, q) {
            B(function () {
                g.paa(a, b, c, d, f, k, m, n, l, q)
            })
        },
        Tb = function () {
            B(function () {
                g.prm()
            })
        },
        Ub = function (a) {
            B(function () {
                g.spn(a)
            })
        },
        Vb = function (a) {
            B(function () {
                g.sps(a)
            })
        },
        Wb = function (a) {
            B(function () {
                g.spp(a)
            })
        },
        Xb = {
            "27": "https://lh3.googleusercontent.com/ogw/default-user=s24",
            "27": "https://lh3.googleusercontent.com/ogw/default-user=s24",
            "27": "https://lh3.googleusercontent.com/ogw/default-user=s24"
        },
        Yb = function (a) {
            return (a = Xb[a]) || "https://lh3.googleusercontent.com/ogw/default-user=s24"
        },
        Zb = function () {
            B(function () {
                g.spd()
            })
        };p("spn", Ub);p("spp", Wb);p("sps", Vb);p("spd", Zb);p("paa", Sb);p("prm", Tb);lb("gbd4", Tb);
    if (h.a("")) {
        var $b = {
            d: h.a(""),
            e: "",
            sanw: h.a(""),
            p: "https://lh3.googleusercontent.com/ogw/default-user=s96",
            cp: "1",
            xp: h.a("1"),
            mg: "%1$s (delegated)",
            md: "%1$s (default)",
            mh: "220",
            s: "1",
            pp: Yb,
            ppl: h.a(""),
            ppa: h.a(""),
            ppm: "Google+ page"
        };
        v.prf = $b
    };
    var S, ac, T, bc, X = 0,
        cc = function (a, b, c) {
            if (a.indexOf) return a.indexOf(b, c);
            if (Array.indexOf) return Array.indexOf(a, b, c);
            for (c = null == c ? 0 : 0 > c ? Math.max(0, a.length + c) : c; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Y = function (a, b) {
            return -1 == cc(a, X) ? (r(Error(X + "_" + b), "up", "caa"), !1) : !0
        },
        ec = function (a, b) {
            Y([1, 2], "r") && (S[a] = S[a] || [], S[a].push(b), 2 == X && window.setTimeout(function () {
                b(dc(a))
            }, 0))
        },
        fc = function (a, b, c) {
            if (Y([1], "nap") && c) {
                for (var d = 0; d < c.length; d++) ac[c[d]] = !0;
                g.up.spl(a, b, "nap", c)
            }
        },
        gc =
        function (a, b, c) {
            if (Y([1], "aop") && c) {
                if (T)
                    for (var d in T) T[d] = T[d] && -1 != cc(c, d);
                else
                    for (T = {}, d = 0; d < c.length; d++) T[c[d]] = !0;
                g.up.spl(a, b, "aop", c)
            }
        },
        hc = function () {
            try {
                if (X = 2, !bc) {
                    bc = !0;
                    for (var a in S)
                        for (var b = S[a], c = 0; c < b.length; c++) try {
                            b[c](dc(a))
                        } catch (d) {
                            r(d, "up", "tp")
                        }
                }
            } catch (d) {
                r(d, "up", "mtp")
            }
        },
        dc = function (a) {
            if (Y([2], "ssp")) {
                var b = !ac[a];
                T && (b = b && !!T[a]);
                return b
            }
        };bc = !1;S = {};ac = {};T = null;X = 1;
    var ic = function (a) {
            var b = !1;
            try {
                b = a.cookie && a.cookie.match("PREF")
            } catch (c) {}
            return !b
        },
        jc = function () {
            try {
                return !!e.localStorage && "object" == typeof e.localStorage
            } catch (a) {
                return !1
            }
        },
        kc = function (a) {
            return a && a.style && a.style.behavior && "undefined" != typeof a.load
        },
        lc = function (a, b, c, d) {
            try {
                ic(document) || (d || (b = "og-up-" + b), jc() ? e.localStorage.setItem(b, c) : kc(a) && (a.setAttribute(b, c), a.save(a.id)))
            } catch (f) {
                f.code != DOMException.QUOTA_EXCEEDED_ERR && r(f, "up", "spd")
            }
        },
        mc = function (a, b, c) {
            try {
                if (ic(document)) return "";
                c || (b = "og-up-" + b);
                if (jc()) return e.localStorage.getItem(b);
                if (kc(a)) return a.load(a.id), a.getAttribute(b)
            } catch (d) {
                d.code != DOMException.QUOTA_EXCEEDED_ERR && r(d, "up", "gpd")
            }
            return ""
        },
        nc = function (a, b, c) {
            a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        oc = function (a) {
            for (var b = 0, c; c = a[b]; b++) {
                var d = g.up;
                c = c in d && d[c];
                if (!c) return !1
            }
            return !0
        },
        pc = function (a, b) {
            try {
                if (ic(a)) return -1;
                var c = a.cookie.match(/OGPC=([^;]*)/);
                if (c && c[1]) {
                    var d = c[1].match(new RegExp("\\b" +
                        b + "-([0-9]+):"));
                    if (d && d[1]) return parseInt(d[1], 10)
                }
            } catch (f) {
                f.code != DOMException.QUOTA_EXCEEDED_ERR && r(f, "up", "gcc")
            }
            return -1
        };p("up", {
        r: ec,
        nap: fc,
        aop: gc,
        tp: hc,
        ssp: dc,
        spd: lc,
        gpd: mc,
        aeh: nc,
        aal: oc,
        gcc: pc
    });
    var Z = function (a, b) {
        a[b] = function (c) {
            var d = arguments;
            g.qm(function () {
                a[b].apply(this, d)
            })
        }
    };Z(g.up, "sl");Z(g.up, "si");Z(g.up, "spl");Z(g.up, "dpc");Z(g.up, "iic");g.mcf("up", {
        sp: h.b("0.01", 1),
        tld: "com",
        prid: "1"
    });

    function qc() {
        function a() {
            for (var l;
                (l = k[m++]) && "m" != l[0] && !l[1].auto;);
            l && (sa(2, l[0]), l[1].url && ra(l[1].url, l[0]), l[1].libs && C && C(l[1].libs));
            m < k.length && setTimeout(a, 0)
        }

        function b() {
            0 < f-- ? setTimeout(b, 0) : a()
        }
        var c = h.a("1"),
            d = h.a(""),
            f = 3,
            k = w,
            m = 0,
            n = window.gbarOnReady;
        if (n) try {
            n()
        } catch (l) {
            r(l, "ml", "or")
        }
        d ? p("ldb", a) : c ? ca(window, "load", b) : b()
    }
    p("rdl", qc);
}
catch (e) {
    window.gbar && gbar.logger && gbar.logger.ml(e, {
        "_sn": "cfg.init"
    });
}
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var b = window.gbar.i.i;
        var c = window.gbar;
        var f = function (d) {
            try {
                var a = document.getElementById("gbom");
                a && d.appendChild(a.cloneNode(!0))
            } catch (e) {
                b(e, "omas", "aomc")
            }
        };
        c.aomc = f;
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var a = window.gbar;
        a.mcf("pm", {
            p: ""
        });
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var a = window.gbar;
        a.mcf("mm", {
            s: "1"
        });
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var d = window.gbar.i.i;
        var e = window.gbar;
        var f = e.i;
        var g = f.c("1", 0),
            h = /\bgbmt\b/,
            k = function (a) {
                try {
                    var b = document.getElementById("gb_" + g),
                        c = document.getElementById("gb_" + a);
                    b && f.l(b, h.test(b.className) ? "gbm0l" : "gbz0l");
                    c && f.k(c, h.test(c.className) ? "gbm0l" : "gbz0l")
                } catch (l) {
                    d(l, "sj", "ssp")
                }
                g = a
            },
            m = e.qs,
            n = function (a) {
                var b = a.href;
                var c = window.location.href.match(/.*?:\/\/[^\/]*/)[0];
                c = new RegExp("^" + c + "/search\\?");
                (b = c.test(b)) && !/(^|\\?|&)ei=/.test(a.href) && (b = window.google) && b.kEXPI && (a.href += "&ei=" + b.kEI)
            },
            p = function (a) {
                m(a);
                n(a)
            },
            q = function () {
                if (window.google && window.google.sn) {
                    var a = /.*hp$/;
                    return a.test(window.google.sn) ? "" : "1"
                }
                return "-1"
            };
        e.rp = q;
        e.slp = k;
        e.qs = p;
        e.qsi = n;
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var a = this || self;
        var b = window.gbar;
        var c = b.i;
        var d = c.a,
            e = c.c,
            f = {
                cty: "USA",
                cv: "386777444",
                dbg: d(""),
                ecv: "0",
                ei: e("c9MJYduFBYfAytMPqsS3iAQ"),
                ele: d("1"),
                esr: e("0.1"),
                evts: ["mousedown", "touchstart", "touchmove", "wheel", "keydown"],
                gbl: "es_plusone_gc_20210707.0_p0",
                hd: "com",
                hl: "en",
                irp: d(""),
                pid: e("1"),
                snid: e("28834"),
                to: e("300000"),
                u: e(""),
                vf: ".66.41."
            },
            g = f,
            h = ["bndcfg"],
            k = a;
        h[0] in k || "undefined" == typeof k.execScript || k.execScript("var " + h[0]);
        for (var l; h.length && (l = h.shift());) h.length || void 0 === g ? k = k[l] && k[l] !== Object.prototype[l] ? k[l] : k[l] = {} : k[l] = g;
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})();
(function () {
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        window.gbar.rdl();
    } catch (e) {
        window.gbar && gbar.logger && gbar.logger.ml(e, {
            "_sn": "cfg.init"
        });
    }
})(); <
/script></head > < body bgcolor = "#fff" > < script nonce = "lRbLF6B7lZu4JWSzjZ0/1A==" > (function () {
    var src = '/images/nav_logo229.png';
    var iesg = false;
    document.body.onload = function () {
        window.n && window.n();
        if (document.images) {
            new Image().src = src;
        }
        if (!iesg) {
            document.f && document.f.q.focus();
            document.gbqf && document.gbqf.q.focus();
        }
    }
})(); < /script><div id="mngb"><div id=gb><script nonce='lRbLF6B7lZu4JWSzjZ0/
1 A == '>window.gbar&&gbar.eli&&gbar.eli()</script><div id=gbw><div id=gbz><span class=gbtcb></span><ol id=gbzc class=gbtc><li class=gbt><a class="gbzt gbz0l gbp1" id=gb_1 href="https://www.google.com/webhp?tab=ww"><span class=gbtb2></span><span class=gbts>Search</span></a></li><li class=gbt><a class=gbzt id=gb_2 href="https://www.google.com/imghp?hl=en&tab=wi"><span class=gbtb2></span><span class=gbts>Images</span></a></li><li class=gbt><a class=gbzt id=gb_8 href="https://maps.google.com/maps?hl=en&tab=wl"><span class=gbtb2></span><span class=gbts>Maps</span></a></li><li class=gbt><a class=gbzt id=gb_78 href="https://play.google.com/?hl=en&tab=w8"><span class=gbtb2></span><span class=gbts>Play</span></a></li><li class=gbt><a class=gbzt id=gb_36 href="https://www.youtube.com/?gl=US&tab=w1"><span class=gbtb2></span><span class=gbts>YouTube</span></a></li><li class=gbt><a class=gbzt id=gb_426 href="https://news.google.com/?tab=wn"><span class=gbtb2></span><span class=gbts>News</span></a></li><li class=gbt><a class=gbzt id=gb_23 href="https://mail.google.com/mail/?tab=wm"><span class=gbtb2></span><span class=gbts>Gmail</span></a></li><li class=gbt><a class=gbzt id=gb_49 href="https://drive.google.com/?tab=wo"><span class=gbtb2></span><span class=gbts>Drive</span></a></li><li class=gbt><a class=gbgt id=gbztm href="https://www.google.com/intl/en/about/products?tab=wh"  aria-haspopup=true aria-owns=gbd><span class=gbtb2></span><span id=gbztms class="gbts gbtsa"><span id=gbztms1>More</span><span class=gbma></span></span></a><script nonce='
lRbLF6B7lZu4JWSzjZ0 / 1 A == '>document.getElementById('
gbztm ').addEventListener('
click ', function clickHandler() { gbar.tg(event,this); });</script><div class=gbm id=gbd aria-owner=gbztm><div id=gbmmb class="gbmc gbsb gbsbis"><ol id=gbmm class="gbmcc gbsbic"><li class=gbmtc><a class=gbmt id=gb_24 href="https://calendar.google.com/calendar?tab=wc">Calendar</a></li><li class=gbmtc><a class=gbmt id=gb_51 href="https://translate.google.com/?hl=en&tab=wT">Translate</a></li><li class=gbmtc><a class=gbmt id=gb_17 href="http://www.google.com/mobile/?hl=en&tab=wD">Mobile</a></li><li class=gbmtc><a class=gbmt id=gb_10 href="https://books.google.com/?hl=en&tab=wp">Books</a></li><li class=gbmtc><a class=gbmt id=gb_6 href="https://www.google.com/shopping?hl=en&source=og&tab=wf">Shopping</a></li><li class=gbmtc><a class=gbmt id=gb_30 href="https://www.blogger.com/?tab=wj">Blogger</a></li><li class=gbmtc><a class=gbmt id=gb_27 href="https://www.google.com/finance?tab=we">Finance</a></li><li class=gbmtc><a class=gbmt id=gb_31 href="https://photos.google.com/?tab=wq&pageId=none">Photos</a></li><li class=gbmtc><a class=gbmt id=gb_12 href="http://video.google.com/?hl=en&tab=wv">Videos</a></li><li class=gbmtc><a class=gbmt id=gb_25 href="https://docs.google.com/document/?usp=docs_alc">Docs</a></li><li class=gbmtc><div class="gbmt gbmh"></div></li><li class=gbmtc><a  href="https://www.google.com/intl/en/about/products?tab=wh" class=gbmt>Even more &raquo;</a><script nonce='
lRbLF6B7lZu4JWSzjZ0 / 1 A == '>document.querySelector('
li > a.gbmt ').addEventListener('
click ', function clickHandler() { gbar.logger.il(1,{t:66});; });</script></li></ol><div class=gbsbt></div><div class=gbsbb></div></div></div></li></ol></div><div id=gbg><h2 class=gbxx>Account Options</h2><span class=gbtcb></span><ol class=gbtc><li class=gbt><a target=_top href="https://accounts.google.com/ServiceLogin?hl=en&passive=true&continue=https://www.google.com/&ec=GAZAAQ" onclick="gbar.logger.il(9,{l:'
i '})" id=gb_70 class=gbgt><span class=gbtb2></span><span id=gbgs4 class=gbts><span id=gbi4s1>Sign in</span></span></a></li><li class="gbt gbtb"><span class=gbts></span></li><li class=gbt><a class=gbgt id=gbg5 href="http://www.google.com/preferences?hl=en" title="Options" aria-haspopup=true aria-owns=gbd5><span class=gbtb2></span><span id=gbgs5 class=gbts><span id=gbi5></span></span></a><script nonce='
lRbLF6B7lZu4JWSzjZ0 / 1 A == '>document.getElementById('
gbg5 ').addEventListener('
click ', function clickHandler() { gbar.tg(event,this); });</script><div class=gbm id=gbd5 aria-owner=gbg5><div class=gbmc><ol id=gbom class=gbmcc><li class="gbkc gbmtc"><a  class=gbmt href="/preferences?hl=en">Search settings</a></li><li class=gbmtc><div class="gbmt gbmh"></div></li><li class="gbkp gbmtc"><a class=gbmt href="http://www.google.com/history/optout?hl=en">Web History</a></li></ol></div></div></li></ol></div></div><div id=gbx3></div><div id=gbx4></div><script nonce='
lRbLF6B7lZu4JWSzjZ0 / 1 A == '>window.gbar&&gbar.elp&&gbar.elp()</script></div></div><center><br clear="all" id="lgpd"><div id="lga"><img alt="Google" height="92" src="/images/branding/googlelogo/1x/googlelogo_white_background_color_272x92dp.png" style="padding:28px 0 14px" width="272" id="hplogo"><br><br></div><form action="/search" name="f"><table cellpadding="0" cellspacing="0"><tr valign="top"><td width="25%">&nbsp;</td><td align="center" nowrap=""><input value="en" name="hl" type="hidden"><input name="source" type="hidden" value="hp"><input name="biw" type="hidden"><input name="bih" type="hidden"><div class="ds" style="height:32px;margin:4px 0"><input class="lst" style="margin:0;padding:5px 8px 0 6px;vertical-align:top;color:#000" autocomplete="off" value="" title="Google Search" maxlength="2048" name="q" size="57"></div><br style="line-height:0"><span class="ds"><span class="lsbb"><input class="lsb" value="Google Search" name="btnG" type="submit"></span></span><span class="ds"><span class="lsbb"><input class="lsb" id="tsuid1" value="I'
m Feeling Lucky " name="
btnI " type="
submit "><script nonce="
lRbLF6B7lZu4JWSzjZ0 / 1 A == ">(function(){var id='tsuid1';document.getElementById(id).onclick = function(){if (this.form.q.value){this.checked = 1;if (this.form.iflsig)this.form.iflsig.disabled = false;}
else top.location = '/doodles/';
};
})(); < /script><input value="AINFCbYAAAAAYQnhg6TmxVxyFYqsBBYm4z2eoOBHz5li" name="iflsig" type="hidden"></span > < /span></td > < td class = "fl sblc"
align = "left"
nowrap = ""
width = "25%" > < a href = "/advanced_search?hl=en&amp;authuser=0" > Advanced search < /a></td > < /tr></table > < input id = "gbv"
name = "gbv"
type = "hidden"
value = "1" > < script nonce = "lRbLF6B7lZu4JWSzjZ0/1A==" > (function () {
    var a, b = "1";
    if (document && document.getElementById)
        if ("undefined" != typeof XMLHttpRequest) b = "2";
        else if ("undefined" != typeof ActiveXObject) {
        var c, d, e = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];
        for (c = 0; d = e[c++];) try {
            new ActiveXObject(d), b = "2"
        } catch (h) {}
    }
    a = b;
    if ("2" == a && -1 == location.search.indexOf("&gbv=2")) {
        var f = google.gbvu,
            g = document.getElementById("gbv");
        g && (g.value = a);
        f && window.setTimeout(function () {
            location.href = f
        }, 0)
    };
}).call(this); < /script></form > < div id = "gac_scont" > < /div><div style="font-size:83%;min-height:3.5em"><br></div > < span id = "footer" > < div style = "font-size:10pt" > < div style = "margin:19px auto;text-align:center"
id = "WqQANb" > < a href = "/intl/en/ads/" > Advertising� Programs < /a><a href="/services / ">Business Solutions</a><a href=" / intl / en / about.html ">About Google</a></div></div><p style="
font - size: 8 pt;
color: #70757a">&copy; 2021 - <a href= "/intl/en/policies/privacy/" > Privacy < /a> - <a href="/intl / en / policies / terms / ">Terms</a></p></span></center><script nonce="
lRbLF6B7lZu4JWSzjZ0 / 1 A == ">(function(){window.google.cdo={height:757,width:1440};(function(){
var a = window.innerWidth,
    b = window.innerHeight;
if (!a || !b) {
    var c = window.document,
        d = "CSS1Compat" == c.compatMode ? c.documentElement : c.body;
    a = d.clientWidth;
    b = d.clientHeight
}
a && b && (a != google.cdo.width || b != google.cdo.height) && google.log("", "", "/client_204?&atyp=i&biw=" + a + "&bih=" + b + "&ei=" + google.kEI);
}).call(this);
})(); < /script> <script nonce="lRbLF6B7lZu4JWSzjZ0/
1 A == ">(function(){google.xjs={ck:'',cs:'',excm:[]};})();</script>  <script nonce="
lRbLF6B7lZu4JWSzjZ0 / 1 A == ">(function(){var u='/xjs/_/js/k\x3dxjs.hp.en_US._K_5Vqr6CRI.O/am\x3dAPgEmA/d\x3d1/ed\x3d1/rs\x3dACT90oGBAjHkUBH-tgcWuWjmhXQtgHDtdQ/m\x3dsb_he,d';
var e = this || self,
    f = function (a) {
        return a
    };
var g;
var l = function (a, b) {
    this.g = b === h ? a : ""
};
l.prototype.toString = function () {
    return this.g + ""
};
var h = {};

function m() {
    var a = u;
    google.lx = function () {
        n(a);
        google.lx = function () {}
    };
    google.bx || google.lx()
}

function n(a) {
    google.timers && google.timers.load && google.tick && google.tick("load", "xjsls");
    var b = document;
    var c = "SCRIPT";
    "application/xhtml+xml" === b.contentType && (c = c.toLowerCase());
    c = b.createElement(c);
    if (void 0 === g) {
        b = null;
        var k = e.trustedTypes;
        if (k && k.createPolicy) {
            try {
                b = k.createPolicy("goog#html", {
                    createHTML: f,
                    createScript: f,
                    createScriptURL: f
                })
            } catch (p) {
                e.console && e.console.error(p.message)
            }
            g = b
        } else g = b
    }
    a = (b = g) ? b.createScriptURL(a) : a;
    a = new l(a, h);
    c.src = a instanceof l && a.constructor === l ? a.g : "type_error:TrustedResourceUrl";
    var d;
    a = (c.ownerDocument && c.ownerDocument.defaultView || window).document;
    (d = (a = null === (d = a.querySelector) || void 0 === d ? void 0 : d.call(a, "script[nonce]")) ? a.nonce || a.getAttribute("nonce") || "" : "") && c.setAttribute("nonce", d);
    document.body.appendChild(c);
    google.psa = !0
};
setTimeout(function () {
m()
}, 0);
})();
(function () {
    window.google.xjsu = '/xjs/_/js/k\x3dxjs.hp.en_US._K_5Vqr6CRI.O/am\x3dAPgEmA/d\x3d1/ed\x3d1/rs\x3dACT90oGBAjHkUBH-tgcWuWjmhXQtgHDtdQ/m\x3dsb_he,d';
})();

function _DumpException(e) {
    throw e;
}

function _F_installCss(c) {}
(function () {
    google.jl = {
        attn: false,
        blt: 'none',
        chnk: 0,
        dw: false,
        emtn: 0,
        end: 0,
        ine: false,
        lls: 'default',
        pdt: 0,
        rep: 0,
        sif: false,
        snet: true,
        strt: 0,
        ubm: false,
        uwp: true
    };
})();
(function () {
    var pmc = '{\x22d\x22:{},\x22sb_he\x22:{\x22agen\x22:true,\x22cgen\x22:true,\x22client\x22:\x22heirloom-hp\x22,\x22dh\x22:true,\x22dhqt\x22:true,\x22ds\x22:\x22\x22,\x22ffql\x22:\x22en\x22,\x22fl\x22:true,\x22host\x22:\x22google.com\x22,\x22isbh\x22:28,\x22jsonp\x22:true,\x22msgs\x22:{\x22cibl\x22:\x22Clear Search\x22,\x22dym\x22:\x22Did you mean:\x22,\x22lcky\x22:\x22I\\u0026#39;m Feeling Lucky\x22,\x22lml\x22:\x22Learn more\x22,\x22oskt\x22:\x22Input tools\x22,\x22psrc\x22:\x22This search was removed from your \\u003Ca href\x3d\\\x22/history\\\x22\\u003EWeb History\\u003C/a\\u003E\x22,\x22psrl\x22:\x22Remove\x22,\x22sbit\x22:\x22Search by image\x22,\x22srch\x22:\x22Google Search\x22},\x22ovr\x22:{},\x22pq\x22:\x22\x22,\x22refpd\x22:true,\x22rfs\x22:[],\x22sbas\x22:\x220 3px 8px 0 rgba(0,0,0,0.2),0 0 0 1px rgba(0,0,0,0.08)\x22,\x22sbpl\x22:16,\x22sbpr\x22:16,\x22scd\x22:10,\x22stok\x22:\x22qmr1pwg30QUnHY4h5Eekzx6fk_U\x22,\x22uhde\x22:false}}';
    google.pmc = JSON.parse(pmc);
})(); < /script>        </body > < /html>